/* =========================
   配置管理文件 - config.js
   ========================= */
window.BYEX_CONFIG = {
  /* ===== 外部链接配置 ===== */
  external_links: {
    // 导航链接
    nav: {
      market: {
        'zh-cn': 'https://www.100ex.com/zh_CN/market',
        'en-us': 'https://www.100ex.com/en/market'
      },
      spot_basic: {
        'zh-cn': 'https://www.100ex.com/zh_CN/trade?tradeType=1',
        'en-us': 'https://www.100ex.com/trade?tradeType=1'
      },
      spot_margin: {
        'zh-cn': 'https://www.100ex.com/zh_CN/margin/BTC_USDT',
        'en-us': 'https://www.100ex.com/margin/BTC_USDT'
      },
      spot_grid: {
        'zh-cn': 'https://www.100ex.com/zh_CN/trade?tradeType=3',
        'en-us': 'https://www.100ex.com/trade?tradeType=3'
      },
      futures: {
        'zh-cn': 'https://futures.100ex.com/zh_CN',
        'en-us': 'https://futures.100ex.com'
      },
      futures_mobile: {
        'zh-cn': 'https://mfutures.100ex.com/zh_CN/',
        'en-us': 'https://mfutures.100ex.com/'
      },
      c2c_normal: {
        'zh-cn': 'https://otc.100ex.com/zh_CN/C2C',
        'en-us': 'https://otc.100ex.com/C2C'
      },
      c2c_ad: {
        'zh-cn': 'https://otc.100ex.com/zh_CN/C2C/merchant/publishAd',
        'en-us': 'https://otc.100ex.com/C2C/merchant/publishAd'
      },
      c2c_merchant: {
        'zh-cn': 'https://otc.100ex.com/zh_CN/C2C/applyMerchant',
        'en-us': 'https://otc.100ex.com/C2C/applyMerchant'
      },
      finance: {
        'zh-cn': 'https://www.100ex.com/zh_CN/finance',
        'en-us': 'https://www.100ex.com/finance'
      },
      byb: {
        'zh-cn': 'https://www.100ex.com/zh_CN/BYB',
        'en-us': 'https://www.100ex.com/BYB'
      },
      loan: {
        'zh-cn': 'https://www.100ex.com/zh_CN/toLoan',
        'en-us': 'https://www.100ex.com/toLoan'
      }
    },

    // 社交媒体链接
    social: {
      telegram: {
        'zh-cn': 'https://t.me/byex',
        'en-us': 'https://t.me/BYEX_Official'
      },
      tiktok: {
        'zh-cn': 'https://www.tiktok.com/@byexchange?_t=ZS-8yhEGR0HNlw&_r=1',
        'en-us': 'https://www.tiktok.com/@byexchange?_t=ZS-8yhEGR0HNlw&_r=1'
      },
      facebook: {
        'zh-cn': 'https://www.facebook.com/share/172nzHGGLz/?mibextid=wwXIfr',
        'en-us': 'https://www.facebook.com/share/172nzHGGLz/?mibextid=wwXIfr'
      },
      x: {
        'zh-cn': 'https://x.com/baiyi_BYEX',
        'en-us': 'https://x.com/100EXOfficial'
      },
      instagram: {
        'zh-cn': 'https://www.instagram.com/byex_exchange/?igsh=MTk2bnN0YTJ3dGl4dw%3D%3D&utm_source=qr#',
        'en-us': 'https://www.instagram.com/byex_exchange/?igsh=MTk2bnN0YTJ3dGl4dw%3D%3D&utm_source=qr#'
      },
      cmc: {
        'zh-cn': 'https://coinmarketcap.com/exchanges/byex/',
        'en-us': 'https://coinmarketcap.com/exchanges/byex/'
      },
      youtube: {
        'zh-cn': 'https://www.youtube.com/@BYEXCN',
        'en-us': 'https://www.youtube.com/@BYEXOfficial'
      }
    },

    // 主要网站链接
    main_site: {
      'zh-cn': 'https://www.100ex.com',
      'en-us': 'https://www.100ex.com'
    }
  },

  /* ===== 文章配置 ===== */
  articles: {
    // 服务卡片对应的文章ID（这些应该从Zendesk动态获取）
    service_cards: {
      registration_guide: '42474568545945', // 注册与下载指南
      // 其他文章ID可以在这里配置
    }
  },

  /* ===== 图片资源配置 ===== */
  images: {
    // 服务卡片图标（使用本地资源）
    service_icons: {
      registration: '{{asset "icons/download.png"}}',
      security: '{{asset "icons/shield-check.png"}}',
      verification: '{{asset "icons/user-trust.png"}}',
      deposit: '{{asset "icons/priority-arrows.png"}}',
      otp: '{{asset "icons/otp.png"}}',
      trading: '{{asset "icons/coins-crypto.png"}}',
      futures: '{{asset "icons/document-signed.png"}}',
      promotions: '{{asset "icons/gift.png"}}',
      c2c: '{{asset "icons/users.png"}}',
      transfer: '{{asset "icons/send-money.png"}}',
      finance: '{{asset "icons/piggy-bank.png"}}',
      loan: '{{asset "icons/discount.png"}}',
      referral: '{{asset "icons/link-alt.png"}}',
      fees: '{{asset "icons/percentage.png"}}'
    },

    // 社交图标（使用本地资源）
    social_icons: {
      telegram: '{{asset "telegram.png"}}',
      tiktok: '{{asset "tiktok.png"}}',
      facebook: '{{asset "facebook.png"}}',
      x: '{{asset "x.png"}}',
      instagram: '{{asset "instagram.png"}}',
      cmc: '{{asset "cmc.png"}}',
      youtube: '{{asset "youtube.png"}}'
    }
  },

  /* ===== 主题设置 ===== */
  theme: {
    brand_color: '#17494D',
    brand_text_color: '#FFFFFF',
    text_color: '#2F3941',
    link_color: '#1F73B7',
    hover_link_color: '#0F3554',
    visited_link_color: '#9358B0',
    background_color: '#FFFFFF'
  }
};

/* ===== 配置获取函数 ===== */
window.getConfig = function(path, locale = null) {
  const currentLocale = locale || window.TranslationSystem?.getCurrentLocale() || 'en-us';
  const keys = path.split('.');
  let value = window.BYEX_CONFIG;
  
  for (const key of keys) {
    if (value && typeof value === 'object' && key in value) {
      value = value[key];
    } else {
      return null;
    }
  }
  
  // 如果是多语言配置，返回对应语言的配置
  if (value && typeof value === 'object' && currentLocale in value) {
    return value[currentLocale];
  }
  
  return value;
};