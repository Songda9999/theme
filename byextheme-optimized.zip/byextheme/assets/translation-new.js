/* =========================
   优化版翻译系统 - translation-new.js
   ========================= */
(function(){
  'use strict';

  /* ===== 语言配置 ===== */
  const SUPPORTED_LANGUAGES = {
    'zh-cn': {
      name: '简体中文',
      translations: window.ZH_TRANSLATIONS || {}
    },
    'en-us': {
      name: 'English', 
      translations: window.EN_TRANSLATIONS || {}
    }
  };

  /* ===== 获取当前语言 ===== */
  function getCurrentLocale() {
    // 1. 从 URL 路径获取
    const pathMatch = location.pathname.match(/\/hc\/([a-z\-]+)(?:\/|$)/i);
    if (pathMatch && pathMatch[1]) {
      return pathMatch[1].toLowerCase().replace('_', '-');
    }

    // 2. 从 Zendesk 全局变量获取
    if (window.HelpCenter) {
      const locale = window.HelpCenter.user?.locale || window.HelpCenter.locale;
      if (locale) {
        return String(locale).toLowerCase().replace('_', '-');
      }
    }

    // 3. 默认返回英文
    return 'en-us';
  }

  /* ===== 获取翻译文本 ===== */
  function getTranslation(key, locale = null) {
    const currentLocale = locale || getCurrentLocale();
    const langConfig = SUPPORTED_LANGUAGES[currentLocale];
    
    if (!langConfig) {
      // 如果当前语言不支持，回退到英文
      const enConfig = SUPPORTED_LANGUAGES['en-us'];
      return enConfig?.translations[key] || key;
    }

    return langConfig.translations[key] || key;
  }

  /* ===== 获取配置链接 ===== */
  function getConfigUrl(path, locale = null) {
    const currentLocale = locale || getCurrentLocale();
    
    // 1. 首先尝试从 manifest.json 设置获取
    const manifestValue = getManifestSetting(path);
    if (manifestValue) {
      return manifestValue;
    }
    
    // 2. 然后尝试从 config.js 获取
    return window.getConfig(path, currentLocale) || '#';
  }

  /* ===== 从 manifest.json 设置获取配置 ===== */
  function getManifestSetting(key) {
    if (!window.HelpCenter || !window.HelpCenter.theme || !window.HelpCenter.theme.settings) {
      return null;
    }

    const settings = window.HelpCenter.theme.settings;
    
    // 映射配置键到设置ID
    const settingMap = {
      'external_links.nav.market': currentLocale === 'zh-cn' ? 'market_url_zh' : 'market_url_en',
      'external_links.nav.futures': currentLocale === 'zh-cn' ? 'futures_url_zh' : 'futures_url_en',
      'external_links.nav.c2c_normal': currentLocale === 'zh-cn' ? 'c2c_url_zh' : 'c2c_url_en',
      'external_links.social.telegram': currentLocale === 'zh-cn' ? 'telegram_url_zh' : 'telegram_url_en',
      'external_links.social.x': currentLocale === 'zh-cn' ? 'x_url_zh' : 'x_url_en',
      'external_links.social.youtube': currentLocale === 'zh-cn' ? 'youtube_url_zh' : 'youtube_url_en',
      'external_links.main_site': 'main_site_url',
      'external_links.social.tiktok': 'tiktok_url',
      'external_links.social.facebook': 'facebook_url',
      'external_links.social.instagram': 'instagram_url',
      'external_links.social.cmc': 'cmc_url'
    };

    const settingId = settingMap[key];
    if (settingId && settings[settingId]) {
      return settings[settingId];
    }

    return null;
  }

  /* ===== 获取Zendesk动态数据 ===== */
  function getZendeskData(type, options = {}) {
    // 这里可以集成Zendesk API来获取动态数据
    // 例如：热门文章、最新文章、分类等
    switch(type) {
      case 'popular_articles':
        return getPopularArticles(options);
      case 'latest_articles':
        return getLatestArticles(options);
      case 'categories':
        return getCategories(options);
      default:
        return [];
    }
  }

  /* ===== 获取热门文章 ===== */
  function getPopularArticles(options = {}) {
    // 这里应该调用Zendesk API获取热门文章
    // 暂时返回空数组，后续可以集成
    return [];
  }

  /* ===== 获取最新文章 ===== */
  function getLatestArticles(options = {}) {
    // 这里应该调用Zendesk API获取最新文章
    // 暂时返回空数组，后续可以集成
    return [];
  }

  /* ===== 获取分类 ===== */
  function getCategories(options = {}) {
    // 这里应该调用Zendesk API获取分类
    // 暂时返回空数组，后续可以集成
    return [];
  }

  /* ===== 应用翻译到 DOM ===== */
  function applyTranslations() {
    const currentLocale = getCurrentLocale();
    console.log('Applying translations for locale:', currentLocale);

    // 1. 翻译文本内容
    document.querySelectorAll('[data-translate-key]').forEach(element => {
      const key = element.getAttribute('data-translate-key');
      if (!key) return;

      const translation = getTranslation(key, currentLocale);
      if (translation && translation !== key) {
        // 检查是否包含 HTML 标签
        if (/<[^>]*>/.test(translation)) {
          element.innerHTML = translation;
        } else {
          element.textContent = translation;
        }
      }
    });

    // 2. 翻译链接（使用配置管理）
    document.querySelectorAll('a[data-config-href]').forEach(link => {
      const configPath = link.getAttribute('data-config-href');
      if (!configPath) return;

      const url = getConfigUrl(configPath, currentLocale);
      if (url && url !== '#') {
        link.setAttribute('href', url);
      }
    });

    // 3. 翻译属性
    document.querySelectorAll('[data-translate-attr]').forEach(element => {
      const attrSpec = element.getAttribute('data-translate-attr');
      if (!attrSpec) return;

      attrSpec.split(';').forEach(pair => {
        const [attr, key] = pair.split(':').map(s => s && s.trim());
        if (!attr || !key) return;

        const translation = getTranslation(key, currentLocale);
        if (translation && translation !== key) {
          element.setAttribute(attr, translation);
        }
      });
    });

    // 4. 翻译搜索占位符
    const searchInput = document.querySelector('input[type="search"]');
    if (searchInput) {
      const placeholder = getTranslation('header_search_placeholder', currentLocale);
      if (placeholder && placeholder !== 'header_search_placeholder') {
        searchInput.setAttribute('placeholder', placeholder);
      }
    }

    // 5. 更新语言显示
    const langConfig = SUPPORTED_LANGUAGES[currentLocale];
    if (langConfig) {
      const langElements = document.querySelectorAll('[data-language-name]');
      langElements.forEach(element => {
        element.textContent = langConfig.name;
      });
    }

    // 6. 应用主题配置
    applyThemeConfig();
  }

  /* ===== 应用主题配置 ===== */
  function applyThemeConfig() {
    const root = document.documentElement;
    
    // 从 manifest.json 设置获取主题配置
    if (window.HelpCenter && window.HelpCenter.theme && window.HelpCenter.theme.settings) {
      const settings = window.HelpCenter.theme.settings;
      
      // 应用颜色配置
      const colorSettings = {
        'brand_color': settings.brand_color,
        'brand_text_color': settings.brand_text_color,
        'text_color': settings.text_color,
        'link_color': settings.link_color,
        'hover_link_color': settings.hover_link_color,
        'visited_link_color': settings.visited_link_color,
        'background_color': settings.background_color
      };

      Object.entries(colorSettings).forEach(([key, value]) => {
        if (value) {
          const cssVar = `--${key.replace(/_/g, '-')}`;
          root.style.setProperty(cssVar, value);
        }
      });
    } else {
      // 回退到 config.js 中的配置
      const theme = window.getConfig('theme');
      if (theme) {
        Object.entries(theme).forEach(([key, value]) => {
          const cssVar = `--${key.replace(/_/g, '-')}`;
          root.style.setProperty(cssVar, value);
        });
      }
    }
  }

  /* ===== 语言切换功能 ===== */
  function switchLanguage(targetLocale) {
    if (!SUPPORTED_LANGUAGES[targetLocale]) {
      console.warn('Unsupported language:', targetLocale);
      return;
    }

    // 构建新的 URL
    const currentPath = location.pathname;
    const newPath = currentPath.replace(/\/hc\/[^\/]+/, `/hc/${targetLocale}`);
    
    // 跳转到新语言页面
    window.location.href = newPath;
  }

  /* ===== 动态加载服务卡片 ===== */
  function loadServiceCards() {
    const serviceCardsContainer = document.querySelector('.service-cards-container');
    if (!serviceCardsContainer) return;

    // 检查是否启用服务卡片
    if (window.HelpCenter && window.HelpCenter.theme && window.HelpCenter.theme.settings) {
      const settings = window.HelpCenter.theme.settings;
      if (settings.enable_service_cards === false) {
        return;
      }
    }

    // 这里可以从Zendesk API获取服务卡片数据
    // 暂时使用静态数据
    const serviceCards = [
      { key: 'service_card_1', icon: 'registration' },
      { key: 'service_card_2', icon: 'security' },
      { key: 'service_card_3', icon: 'verification' },
      { key: 'service_card_4', icon: 'deposit' },
      { key: 'service_card_5', icon: 'otp' },
      { key: 'service_card_6', icon: 'trading' },
      { key: 'service_card_7', icon: 'futures' },
      { key: 'service_card_8', icon: 'promotions' },
      { key: 'service_card_9', icon: 'c2c' },
      { key: 'service_card_10', icon: 'transfer' },
      { key: 'service_card_11', icon: 'finance' },
      { key: 'service_card_12', icon: 'loan' },
      { key: 'service_card_13', icon: 'referral' },
      { key: 'service_card_14', icon: 'fees' }
    ];

    const currentLocale = getCurrentLocale();
    const iconConfig = window.getConfig('images.service_icons');

    serviceCards.forEach((card, index) => {
      const title = getTranslation(card.key + '_title', currentLocale);
      const desc = getTranslation(card.key + '_desc', currentLocale);
      const url = getTranslation(card.key + '_url', currentLocale);
      const icon = iconConfig[card.icon] || '';

      // 创建服务卡片HTML
      const cardHTML = `
        <a href="${url}" class="service-card" data-translate-key="${card.key}">
          <div class="service-card-icon">
            <img src="${icon}" alt="${title}">
          </div>
          <div class="service-card-content">
            <h3 data-translate-key="${card.key}_title">${title}</h3>
            <p data-translate-key="${card.key}_desc">${desc}</p>
          </div>
        </a>
      `;

      serviceCardsContainer.insertAdjacentHTML('beforeend', cardHTML);
    });
  }

  /* ===== 应用自定义CSS和JS ===== */
  function applyCustomCode() {
    if (!window.HelpCenter || !window.HelpCenter.theme || !window.HelpCenter.theme.settings) {
      return;
    }

    const settings = window.HelpCenter.theme.settings;

    // 应用自定义CSS
    if (settings.custom_css) {
      const style = document.createElement('style');
      style.textContent = settings.custom_css;
      document.head.appendChild(style);
    }

    // 应用自定义JavaScript
    if (settings.custom_js) {
      try {
        eval(settings.custom_js);
      } catch (error) {
        console.error('Error executing custom JavaScript:', error);
      }
    }

    // 应用Google Analytics
    if (settings.google_analytics_id) {
      const gaScript = document.createElement('script');
      gaScript.async = true;
      gaScript.src = `https://www.googletagmanager.com/gtag/js?id=${settings.google_analytics_id}`;
      document.head.appendChild(gaScript);

      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', settings.google_analytics_id);
    }

    // 应用Facebook Pixel
    if (settings.facebook_pixel_id) {
      const fbScript = document.createElement('script');
      fbScript.innerHTML = `
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '${settings.facebook_pixel_id}');
        fbq('track', 'PageView');
      `;
      document.head.appendChild(fbScript);
    }
  }

  /* ===== 初始化 ===== */
  function init() {
    // 等待 DOM 加载完成
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        applyTranslations();
        loadServiceCards();
        applyCustomCode();
      });
    } else {
      applyTranslations();
      loadServiceCards();
      applyCustomCode();
    }

    // 监听动态内容变化
    const observer = new MutationObserver((mutations) => {
      let shouldReapply = false;
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === 1 && (
              node.hasAttribute('data-translate-key') ||
              node.querySelector('[data-translate-key]')
            )) {
              shouldReapply = true;
            }
          });
        }
      });
      
      if (shouldReapply) {
        setTimeout(applyTranslations, 100);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  /* ===== 暴露全局函数 ===== */
  window.TranslationSystem = {
    getTranslation,
    getConfigUrl,
    getCurrentLocale,
    switchLanguage,
    applyTranslations,
    getZendeskData,
    SUPPORTED_LANGUAGES
  };

  /* ===== 启动 ===== */
  init();

})();