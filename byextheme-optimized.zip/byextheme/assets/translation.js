/* =========================
   translation.js  (完整可用版)
   ========================= */
(function(){
  'use strict';

  /* ===== 你的词库（含 community.topnav.*、footercommunity.link.*、about.*、community.label.*、shared.security.*） ===== */
  const translations = {
    'zh-cn': {
      /* ===== 顶部导航 ===== */
      nav_market: '市场行情',                                 nav_market_url: 'https://www.100ex.com/zh_CN/market',
      nav_spot: '现货交易',
      nav_spot_basic: '币币交易',                               nav_spot_basic_url: 'https://www.100ex.com/zh_CN/trade?tradeType=1',
      nav_spot_margin: '杠杆交易',                             nav_spot_margin_url: 'https://www.100ex.com/zh_CN/margin/BTC_USDT',
      nav_spot_grid: '网格交易',                                nav_spot_grid_url: 'https://www.100ex.com/zh_CN/trade?tradeType=3',
      nav_futures: '合约交易',                                 nav_futures_url: 'https://futures.100ex.com/zh_CN', nav_futures_mobile_url: 'https://mfutures.100ex.com/zh_CN/',
      nav_c2c: 'C2C 交易',
      nav_c2c_normal: '普通交易',                               nav_c2c_normal_url: 'https://otc.100ex.com/zh_CN/C2C',
      nav_c2c_ad: '发布广告',                                   nav_c2c_ad_url: 'https://otc.100ex.com/zh_CN/C2C/merchant/publishAd',
      nav_c2c_merchant: '申请商户',                             nav_c2c_merchant_url: 'https://otc.100ex.com/zh_CN/C2C/applyMerchant',
      nav_finance: '金融理财',                                 nav_finance_url: 'https://www.100ex.com/zh_CN/finance',
      nav_byb: 'BYB 专区',                                   nav_byb_url: 'https://www.100ex.com/zh_CN/BYB',
      nav_loan: '抵押借贷',                                   nav_loan_url: 'https://www.100ex.com/zh_CN/toLoan',
      nav_switch_lang: '切换语言',

      /* ===== 首页/公共文本 ===== */
      header_welcome: '欢迎访问',
      header_title: '佰易帮助中心',
      header_search_placeholder: '搜索或提问',
      self_service_title: '自助服务',
      more: '更多 >',
      self_service_more_url: 'selfservice.html',
      faq_more_url: '#',
      chat_support_card_url: '#',

      /* ===== 各种服务卡片（原样保留） ===== */
      service_card_1_title: '注册与下载指南',                   service_card_1_url: 'article.html?article=42474568545945',
      service_card_1_desc: 'iOS/安卓下载教程及注册流程，含海外 ID 切换说明',
      service_card_1_desc_mobile: 'iOS/安卓下载教程及注册流程',
      service_card_2_title: '账户安全设置',                     service_card_2_url: '#',
      service_card_2_desc: '绑定邮箱手机、设置密码、开启谷歌验证',
      service_card_2_desc_mobile: '绑定邮箱手机、设置密码等',
      service_card_3_title: '身份认证',                         service_card_3_url: '#',
      service_card_3_desc: '提交身份证件信息以提升账户等级和安全性',
      service_card_3_desc_mobile: '提升账户等级和安全性',
      service_card_4_title: '充值与提现',                       service_card_4_url: '#',
      service_card_4_desc: '链上确认时间、到账异常、最小限额等问题',
      service_card_4_desc_mobile: '到账异常、最小限额等问题',
      service_card_5_title: '验证码与验证器问题',             service_card_5_url: '#',
      service_card_5_desc: '验证码收不到、谷歌验证器重置等处理方式',
      service_card_5_desc_mobile: '验证码收不到、谷歌验证器重置',
      service_card_6_title: '交易操作指南',                     service_card_6_url: '#',
      service_card_6_desc: '现货、合约等交易流程，含资金划转',
      service_card_6_desc_mobile: '现货、合约等交易流程',
      service_card_7_title: '合约交易问答',                     service_card_7_url: '#',
      service_card_7_desc: '张数、保证金、资金费率、回报率等核心概念解读',
      service_card_7_desc_mobile: '保证金、资金费率等核心概念',
      service_card_8_title: '活动与奖励公告',                   service_card_8_url: '#',
      service_card_8_desc: '最新活动说明、参与条件、奖励发放公示',
      service_card_8_desc_mobile: '最新活动、参与条件、奖励发放',
      service_card_9_title: 'C2C 交易',                         service_card_9_url: '#',
      service_card_9_desc: 'C2C 买卖流程、订单风控与申诉处理',
      service_card_9_desc_mobile: '买卖流程、订单风控与申诉',
      service_card_10_title: '批量转账',                        service_card_10_url: '#',
      service_card_10_desc: '支持按 UID 批量发起内部转账，适用于多账户资金划转',
      service_card_10_desc_mobile: '按 UID 批量发起内部转账',
      service_card_11_title: '金融理财',                        service_card_11_url: '#',
      service_card_11_desc: '活期、定期、余额宝等理财功能的参与方式与规则',
      service_card_11_desc_mobile: '活期、定期、余额宝等功能',
      service_card_12_title: '抵押借贷',                        service_card_12_url: '#',
      service_card_12_desc: '使用加密资产作为抵押，获取 USDT 借贷额度',
      service_card_12_desc_mobile: '使用加密资产获取USDT借贷',
      service_card_13_title: '推广返佣计划',                    service_card_13_url: '#',
      service_card_13_desc: '邀请好友赚返佣，查看邀请记录和返佣比',
      service_card_13_desc_mobile: '邀请好友赚返佣',
      service_card_14_title: '手续费与费率说明',                service_card_14_url: '#',
      service_card_14_desc: '吃单/挂单、充提、合约等手续费标准说明',
      service_card_14_desc_mobile: '吃单/挂单、充提、合约等',

      /* ===== FAQ/Guide/Announce ===== */
      faq_title: '常见问题',
      faq_popular: '热门问题',
      faq_latest: '最新发布文章',
      guide_wallet_title: '佰易钱包指南',                       guide_wallet_more_url: '#',
      guide_wallet_1: '钱包专业模式简介',                       guide_wallet_1_url: '#',
      guide_wallet_2: '如何使用钱包',                           guide_wallet_2_url: '#',
      guide_kyc_title: '实名认证',                              guide_kyc_more_url: '#',
      guide_kyc_1: '如何完成个人认证',                         guide_kyc_1_url: '#',
      guide_kyc_2: '企业认证全流程',                           guide_kyc_2_url: '#',
      guide_c2c_title: '佰易 C2C 介绍',                        guide_c2c_more_url: '#',
      guide_c2c_1: 'C2C交易介绍',                              guide_c2c_1_url: '#',
      guide_c2c_2: '提领限额说明',                             guide_c2c_2_url: '#',
      guide_security_title: '安全指南',                         guide_security_more_url: '#',
      guide_security_1: '2FA 安全提示',                         guide_security_1_url: '#',
      guide_security_2: '如何防范网络钓鱼',                     guide_security_2_url: '#',
      announcements_title: '公告中心',                           announcements_more_url: '#',
      announcements_1: '数字货币及交易对上新',                  announcements_1_url: '#',
      announcements_2: '佰易最新动态',                          announcements_2_url: '#',
      announcements_3: '佰易最新活动',                          announcements_3_url: '#',
      announcements_4: '法币及交易对上新',                      announcements_4_url: '#',

      more_help_title: '需要更多帮助？',
      more_help_chat_title: '聊天支持',
      more_help_chat_desc: '如有任何问题，请随时联系我们。聊天支持团队全天候为您提供服务。',
      more_help_chat_cta: '查看更多',

      /* ===== Footer ===== */
      footer_community: '社区',
      footer_about: '关于我们',
      footer_about_1: '关于我们',                                footer_about_1_url: 'https://100ex.zendesk.com/hc/p/about',
      footer_about_2: '用户协议',                                footer_about_2_url: 'https://100ex.zendesk.com/hc/p/UserAgreement',
      footer_about_3: '免责声明',                                footer_about_3_url: 'https://100ex.zendesk.com/hc/p/Disclaimer',
      footer_about_4: '隐私条款',                                footer_about_4_url: '#',
      footer_about_5: '联系我们',                                footer_about_5_url: '#',
      footer_products: '产品',
      footer_products_1: '交易所',                               footer_products_1_url: '#',
      footer_products_2: '支付钱包',                             footer_products_2_url: '#',
      footer_products_3: 'C2C 交易',                             footer_products_3_url: '#',
      footer_products_4: 'BYB 质押',                             footer_products_4_url: '#',
      footer_services: '服务',
      footer_services_1: '费率标准',                             footer_services_1_url: '#',
      footer_services_2: '邀请好友',                             footer_services_2_url: '#',
      footer_services_3: 'BYB 专区',                             footer_services_3_url: '#',
      footer_services_4: '公告中心',                             footer_services_4_url: '#',
      footer_services_5: '认证商家服务协议',                     footer_services_5_url: '#',
      footer_learn: '学习',
      footer_learn_1: '新手行业了解',                           footer_learn_1_url: '#',
      footer_learn_2: '区块链基础科普',                          blockchain_basics_url: '#',
      footer_learn_3: '区块链词典',                             blockchain_glossary_url: '#',
      footer_risk: '风险与合规',
      footer_risk_1: '风险告知书',                               risk_disclosure_url: '#',
      footer_risk_2: '违规交易说明',                             irregular_trading_url: '#',
      footer_risk_3: '保证金参数',                               margin_parameters_url: '#',
      footer_copyright: '© 2025 佰易. 版权所有.',
      language_modal_title: '语言',
      select_language: '选择语言',
      loading: '正在加载...',
      no_articles: '暂无文章。',
      load_fail: '加载文章失败。',
      no_section_id: '请在代码中设置一个或多个Section ID。',

      /* ===== 社区（community.*） ===== */
      'community.social_title': '社交媒体频道',
      'community.official_title': '官方频道',
      'community.subtitle': '加入讨论，第一时间获取最新公告！',
      'community.pill_exchange': '交易所',

      'community.card_en_title': '英文',
      'community.card_zh_title': '中文',
      'community.card_announce_title': '公告中心',

      'community.open_tg_text': '打开 Telegram 群',

      'community.copy_tip': '点击复制',
      'community.copied': '已复制',
      'community.copy_fail': '复制失败',

      /* 标签文字（用于图标下方 label） */
      'community.label.telegram': 'Telegram',
      'community.label.tiktok': 'TikTok',
      'community.label.facebook': 'Facebook',
      'community.label.x': 'X',
      'community.label.instagram': 'Instagram',
      'community.label.cmc': 'CoinMarketCap',
      'community.label.youtube': 'YouTube',

      /* 图标 alt 文案 */
      'community.alt.telegram': 'Telegram',
      'community.alt.tiktok': 'TikTok',
      'community.alt.facebook': 'Facebook',
      'community.alt.x': 'X',
      'community.alt.instagram': 'Instagram',
      'community.alt.cmc': 'CoinMarketCap',
      'community.alt.youtube': 'YouTube',

      /* 社区页链接（community.hbs） */
      'community.link.telegram_url': 'https://100ex.zendesk.com/hc/p/community',
      'community.link.tiktok_url': 'https://www.tiktok.com/@byexchange?_t=ZS-8yhEGR0HNlw&_r=1',
      'community.link.facebook_url': 'https://www.facebook.com/share/172nzHGGLz/?mibextid=wwXIfr',
      'community.link.x_url': 'https://x.com/baiyi_BYEX',
      'community.link.instagram_url': 'https://www.instagram.com/byex_exchange/?igsh=MTk2bnN0YTJ3dGl4dw%3D%3D&utm_source=qr#',
      'community.link.cmc_url': 'https://coinmarketcap.com/exchanges/byex/',
      'community.link.youtube_url': 'https://www.youtube.com/@BYEXCN',

      'community.en_url': 'https://t.me/BYEX_Official',
      'community.zh_url': 'https://t.me/byex',
      'community.announce_url': 'https://t.me/baiyi',

      /* Footer 专用社交链接（按语言切换） */
      'footercommunity.link.telegram_url': 'https://100ex.zendesk.com/hc/zh-cn/p/community',
      'footercommunity.link.tiktok_url':   'https://www.tiktok.com/@byexchange?_t=ZS-8yhEGR0HNlw&_r=1',
      'footercommunity.link.facebook_url': 'https://www.facebook.com/share/172nzHGGLz/?mibextid=wwXIfr',
      'footercommunity.link.x_url':        'https://x.com/baiyi_BYEX',
      'footercommunity.link.instagram_url':'https://www.instagram.com/byex_exchange/?igsh=MTk2bnN0YTJ3dGl4dw%3D%3D&utm_source=qr#',
      'footercommunity.link.cmc_url':      'https://coinmarketcap.com/exchanges/byex/',
      'footercommunity.link.youtube_url':  'https://www.youtube.com/@BYEXCN',

      /* 顶部子导航（About/Community） */
      'community.topnav.about': '关于我们',
      'community.topnav.about_url': 'https://100ex.zendesk.com/hc/p/about',
      'community.topnav.community': '社区',
      'community.topnav.community_url': 'https://100ex.zendesk.com/hc/p/community',

      /* ===== About 页面（about.*） ===== */
      'about.title': '公司简介',
      'about.lead': 'BYEX 是一家领先的数字资产平台，致力于为用户提供安全、便捷的数字资产交易、管理和存储解决方案。平台旨在弥合传统金融与区块链技术的鸿沟，满足个人、机构和企业在数字资产管理方面日益增长的需求，推动金融创新与资产管理的发展。',
      'about.hero_img_alt': 'BYEX 平台概览',

      'about.mission_title': '使命',
      'about.mission_desc': '通过提供一个安全、透明且易于使用的平台，促进数字资产的便捷获取，赋能全球用户。',
      'about.vision_title': '愿景',
      'about.vision_desc': '成为全球最值得信赖的数字资产平台，促进区块链技术与去中心化金融的广泛应用。',

      'about.values_title': '核心价值观',
      'about.values.security_title': '安全',
      'about.values.security_desc': '保护用户资产和数据的安全。',
      'about.values.transparency_title': '透明',
      'about.values.transparency_desc': '清晰、开放、诚信的运营。',
      'about.values.innovation_title': '创新',
      'about.values.innovation_desc': '提供前沿的数字资产解决方案。',
      'about.values.ease_title': '便捷性',
      'about.values.ease_desc': '让每个人都能轻松使用数字资产。',
      'about.values.customer_title': '客户至上',
      'about.values.customer_desc': '提供卓越的用户体验和服务支持。',

      'about.services_title': '主要服务',
      'about.services.trade_title': '数字资产交易',
      'about.services.trade_desc': '便捷的加密货币和数字资产买卖。',
      'about.services.wallet_title': '钱包服务',
      'about.services.wallet_desc': '安全存储数字资产的数字钱包。',
      'about.services.stake_title': '质押与收益',
      'about.services.stake_desc': '通过质押与流动性挖矿获得被动收入。',
      'about.services.institution_title': '机构服务',
      'about.services.institution_desc': '定制化的流动性管理和场外交易（C2C）解决方案。',

      /* —— 统一版技术与安全 —— */
      'shared.security.title': '技术与安全',
      'shared.security.desc': '平台采用先进的安全措施，包括多因素认证（MFA）、加密技术、冷存储解决方案和实时监控，确保用户资产的安全。我们严格遵循行业法规，提供合规的交易环境。',

      'about.why_title': '为什么选择 BYEX？',
      'about.why.ui_title': '便捷直观的界面',
      'about.why.ui_desc': '交易与资产管理更高效。',
      'about.why.security_title': '顶尖安全与风控',
      'about.why.security_desc': '保护资产与交易全流程。',
      'about.why.fee_title': '具竞争力的费率',
      'about.why.fee_desc': '更划算地完成交易。',
      'about.why.support_title': '7×24 客服支持',
      'about.why.support_desc': '随时随地为你解答。',
      'about.why.defi_title': '区块链与 DeFi 集成',
      'about.why.defi_desc': '前沿功能，持续更新。',

      'about.cta_title': '加入 BYEX，开启数字资产新机遇',
      'about.cta_desc': '立即体验安全、透明、好用的数字资产平台。',
      'about.cta_btn': '前往交易',
      'about.cta_url': 'https://www.100ex.com',

/* ===== 免责声明（中文） ===== */
'disclaimer.title': '免责声明',
'disclaimer.updated_label': '最后更新时间：',
'disclaimer.updated_value': '2019年 07月 12日',
'disclaimer.content': `
<p>本免责声明应与《佰易国际 服务协议》和《佰易国际 隐私协议》的服务条款一起阅读。简单来讲，我们希望当您在我们的平台上交易时能够理解相关重要的风险和合规事宜。</p>

<h2>目的</h2>
<p>本网站的宗旨是在不违反相关法律法规的前提下，尽可能地为全球广大数字资产爱好者与股票爱好者及用户提供专业、安全、可信赖的数字资产交易及资产管理服务。我们致力于推进合法、透明的商业活动，并在用户、监管机构和数字资产行业中保持一个良好的声誉。</p>

<h2>业务模式</h2>
<p>我们是一家全球性的数字资产交易平台，或称交易市场，交易者以买方和卖方的身份来此交易，通常被称为市场交易商和市场接受者。为清楚起见，买方和卖方彼此之间进行交易，而佰易国际不参与到实际交易中。用户可以登陆 <a href="https://www.100ex.com" target="_blank" rel="noopener">www.100ex.com</a> 及其相关应用程序界面或移动应用程序（网站），以获得佰易国际提供的服务。</p>
<p><strong>披露：</strong>交易有风险。交易或持有数字资产的损失风险可能很大。因此，您应根据您的财务状况仔细考虑您是否适合进行交易。</p>

<h2>监管环境</h2>
<p>数字资产不是钱或法定货币。比特币和莱特币等数字资产不以任何政府或中央银行为后盾支持。在不同时期我们可能会对各政府机构所采取的监管方式有些见解；但是，我们会一直全面遵守我们经营所在国家的规章制度。同时，我们定期与监管机构和同行探讨监管数字资产业务的最佳方法。此外，佰易国际不接受某些客户。为了保持在市场上的良好声誉并确保一个强大的合规市场，如过您所在国家或地区属于监管明确禁止数字资产交易的法域或属于被列入相关受制裁国家名单的，您应禁止使用本网站项下的服务。</p>

<h2>地区限制</h2>
<p>根据我们平台的使用条款，如果您位于以下国家或地区、在此注册成立、或作为其公民或居民，则不允许访问和使用我们的平台及提供的服务。以下是受限国家或地区的概览：</p>

<ul class="ua-dot">
  <li>关岛</li>
  <li>波多黎各</li>
  <li>美属维尔京群岛</li>
  <li>朝鲜</li>
  <li>古巴</li>
  <li>伊朗</li>
  <li>中国大陆</li>
  <li>白俄罗斯</li>
  <li>克里米亚</li>
  <li>刚果民主共和国</li>
  <li>伊拉克</li>
  <li>苏丹</li>
  <li>叙利亚</li>
  <li>南苏丹</li>
  <li>萨摩亚</li>
  <li>巴拿马</li>
  <li>委内瑞拉</li>
</ul>

<p>请注意，除此之外，其他一些司法管辖区也可能受到（部分）限制。</p>

<p>我们与政府部门合作并遵守适用法规。作为良好的企业公民，执法部门可能会要求我们提供信息，并且如果法律允许执法调查以追查和阻止非法活动，我们将提供帮助。这也意味着我们的平台仅适用于守法的客户。我们希望能为您提供服务，同时，我们也希望您在我们的平台上能够依法合法地行事。</p>
<p>本协议全部内容均为根据相关法律而订立，其成立、解释、内容及执行均适用相关法律规定；本网站使用者因为违反本声明的规定而触相关法律的，本网站作为服务的提供方，有义务对平台的规则及服务进行完善，但本站并无触犯相关法律的动机和事实，对使用者的行为不承担任何连带责任。</p>

<h2>我们的反洗钱/反恐怖融资方案</h2>
<p>通过基于风险的多层次控制系统，我们设计了我们的反洗钱和反恐怖融资方案以合理防止洗钱和恐怖主义融资。</p>
<p>该方案包括严格的用户身份识别程序，包括验证个人和企业用户的身份。除了获得身份证明文件外，我们还向非自然人用户取得其机构受益所有人/自然人的信息。</p>
<p>包括持续监控可疑活动。如果我们怀疑或有理由怀疑存在可疑交易活动，我们将酌情向当地监管机构提交可疑交易活动报告。通常，可疑交易与客户已知的合法业务或个人日常交易活动不一致。</p>
<p>凡以任何方式登录本网站或直接、间接使用本网站服务者，视为自愿接受本网站声明的约束。</p>

<h2>风险</h2>
<div>
  <p><span class="idx">5.1</span> 数字资产交易被认为具有高风险。数字资产不以任何政府或中央银行为后盾支持。交易或持有数字资产的风险可能很大。您应该根据您的财务状况仔细考虑交互，持有或交易数字资产是否适合您。</p>
  <p><span class="idx">5.2</span> 在任何和所有情况下，佰易国际对任何因使用平台而产生的惩罚性的、间接的、偶然的、特殊的或连带的损失或损害均不承担责任，包括但不限于间接个人损害、商业盈利的丧失、交易中断、商业信息的丢失或任何其它相关利益损失。</p>
  <p><span class="idx">5.3</span> 投资证券或金融产品存在亏损风险，佰易国际不对客户的投资活动产生的损失承担任何责任。</p>
  <p><span class="idx">5.4</span> 由于存在互联网黑客恶意攻击、网络服务器故障及其他不可预测的因素，行情信息及其他证券相关信息可能会出现错误或延迟。</p>
  <p><span class="idx">5.5</span> 佰易国际APP所包含的资讯、市场数据、图表、图解、新闻、帖子、评论、观点、财务数据、股东分析、估值分析和股票诊断(统称为“信息”)均来自被认为是准确和及时的来源。佰易国际、其附属公司及其内容提供商均无法:
(1)就信息的可靠度、准确性或完整性作出任何陈述或保证;
(2)保证佰易国际app所载的任何信息是不间断的或无错误的; 或
(3)将对使用或传播任何该类信息承担任何责任。
在法律允许的情况下,佰易国际及其附属公司明确表示不会就个人或实体依据佰易国际app上所载的信息引起的或相关的任何直接、间接、特殊、偶然、后果性或惩罚性的损失或损坏,包括但不限于佰易国际app上所载的信息有任何错误或遗漏，而对任何人承担任何职责或法律责任。</p>
  <p><span class="idx">5.6</span> 客户的网络终端设备及软件系统可能会受到非法攻击或病毒感染，导致无法下达委托或委托失败。</p>
  <p><span class="idx">5.7</span> 若客户的网络终端设备及软件系统与佰易国际提供的网上交易系统不兼容，导致无法下达委托或委托失败，客户可以寻找佰易国际的客户服务，并报告该类情况和获得技术支持。但佰易国际无法保证就不可控制的情形导致的（委托）失败进行任何经济赔偿。</p>
</div>

<h2>其他约定</h2>
<p>本平台对本协议在法律许可的范围内拥有最终的解释权。如果这些声明与您可能与佰易国际达成的任何其他协议之间存在任何冲突，以相关法律法规为准。</p>
</div>
      `,  

      /* ===== 用户协议（中文） ===== */
      'user_agreement.title': '用户协议',
      'user_agreement.updated_label': '最后更新时间：',
      'user_agreement.updated_value': '2019年 07月 12日',	
      'user_agreement.content': `
<div class="ua-rich">
  <p>佰易国际该公司及其关联公司（以下合称为“公司”或“佰易国际”）联合运营网站：www.100ex.com 及相关移动应用（以下简称“平台”或“本平台”），并基于该平台为用户提供数字货币之间的交易及相关服务。就本协议而言，关联公司系指直接或间接通过一个或多个中间方控制佰易国际、受其控制或与其处于共同控制之下的另一实体。若您注册成为本平台用户即表示您同意接受本协议并受平台发布的所有协议和网站公布的所有政策的约束（以下简称“协议”）。若您不接受以下协议，请立即停止注册，停止访问网站，及/或停止使用本平台的服务、产品或内容。</p>

  <h2>第一章 协议签署与修订</h2>
  <p>1.1您声明并确保您已年满18岁，具有法律规定的完全民事行为能力，且没有被剥夺过使用我们的服务的权利。若您不符合上述条件，请不要注册我们的网站或平台，否则公司有权随时暂停或终止您的帐户。</p>
  <p>1.2您订立并履行本协议不受您所属、所居住、开展经营活动或其他业务、或对您有税务管辖权的国家或地区法律法规的禁止。若您不具备前述条件，您应立即终止注册或停止使用本平台服务。</p>
  <p>1.3您按照平台页面上的提示完成全部的注册程序或后续每一次使用平台的相关服务，即表示您完全理解并接受本协议项下的全部内容（包括后续不时作出并在平台上发布的修订版协议内容）。本协议内容包括本协议项下全部协议及本平台已经发布的或将来可能发布的各类规则。所有已发布或将来可能发布的各类规则均明确纳入并构成本协议不可分割的一部分，与协议正文具有同等法律效力。</p>
  <p>1.4本平台有权根据需要不时地修改本协议或根据本协议制定、修改各类具体规则并在本平台相关系统板块发布，无需另行单独通知您。您应不时地注意本协议及具体规则的变更，若您在本协议及具体规则内容公告变更后继续使用本服务，则视为您已充分阅读、理解并接受修改后的协议和具体规则内容，也将遵循修改后的协议和具体规则使用本平台的服务。</p>
  <p>1.5接受本协议或根据本协议及平台有关规则及指示操作您的账户（无论是亲自操作或通过他人操作）访问本平台的相关服务，即视为本协议在您和佰易国际之间产生法律效力。本协议不涉及您与本平台的其他用户之间因网络服务或交易而产生的法律关系或法律纠纷（如有）。</p>
  <p>1.6您同意佰易国际可以通过发出通知自行决定立即终止您对本平台和帐户的访问，包括但不限于以下权利：限制、暂停或终止服务和用户帐户，禁止访问平台及其内容、服务和工具，延迟或删除内容，采取技术和法律措施使侵权或者违反本协议和平台政策的用户脱离平台，以及任何进一步措施以弥补任何造成的损失或损害，一旦我们自行判定您可能违反任何法律、法规、第三方的权利、或任何本协议或平台政策内容。佰易国际对因行使本条款下之权利而给您或任何第三方造成之任何损失或损害概不负责。</p>

  <h2>第二章 服务内容及您的权利和义务</h2>
  <p>2.1 佰易国际为您提供数字资产交易服务。本平台并不作为买家或卖家与用户直接交易，且不提供任何国家法定货币充入和提取的相关服务。</p>
  <p>2.1.1您有权在平台浏览数字货币实时行情及交易信息、有权通过平台提交数字货币交易指令并完成数字货币交易。</p>
  <p>2.1.2您有权在平台查看您账号下的信息，有权应用平台提供的功能进行操作。</p>
  <p>2.1.3您有权按照平台发布的活动规则参与平台组织的网站活动，以及平台承诺为您提供的其他服务。</p>
  <p>2.2您理解并同意，平台可自行根据实际情况随时调整平台上的服务内容、服务种类及服务形式。对于因平台调整给您或任何第三方造成的负面影响或损失，本平台概不负责。</p>
  <p>2.3根据您所在的国家/地区，您可能无法使用本网站或平台的所有功能。我们有权暂停为特定国家的用户提供某些服务，但确保在访问本网站、平台和使用我们的服务的过程中遵守法律和法规（包括您所居住的及/或您访问本网站时所在的国家/地区的法律和法规）是您的责任。</p>
  <p>2.4为了访问和使用我们的服务，您必须使用佰易国际创建一个帐户。您同意：</p>
  <p>（1）创建帐户时提供准确，最新和完整的信息；</p>
  <p>（2）维护并及时更新您的帐户信息，以使其准确，完整和最新；</p>
  <p>（3）维护您的登录凭据的安全性和机密性，并限制对您的帐户和计算机的访问；</p>
  <p>（4）如果您发现或怀疑与平台有关的任何安全漏洞，应立即通知汇信国际；</p>
  <p>（5）对您帐户下发生的所有活动负责，并承担未经授权访问的所有风险；</p>
  <p>2.5为向您提供服务时，平台将可能合理使用您的用户个人信息、非个人信息及第三方提供的信息（以下合称“用户信息”）。您一旦注册、登录、使用本平台服务，将视为您完全了解、同意并接受本公司通过包括但不限于收集、统计、分析、等方式合理使用用户信息。</p>
  <p>2.6您确认，您在本平台上按本平台服务流程所确认的交易状态将成为本平台为您进行相关交易或操作的明确指令。您同意本平台有权按相关指令依据本协议和/或有关文件和规则对相关事项进行处理。</p>
  <p>2.7因您未能及时对交易状态进行修改或确认或未能提交相关申请所引起的任何纠纷或损失由您本人负责，本平台不承担任何责任。</p>

  <h2>第三章 业务风险提示与确认</h2>
  <p>3.1借币以及超级杠杆交易风险提示与确认</p>
  <p>3.1.1 佰易国际推出借币服务，为您提供做多/做空超级杠杆交易服务。</p>
  <p>3.1.2您的最高借币数量由最高借币倍数决定。</p>
  <p>3.1.3 佰易国际为借币您的超级杠杆交易提供风险管理服务，对您在佰易国际的超级超级杠杆账户进行监控和风险管理。</p>
  <p>3.1.4当您使用超级杠杆交易时，即默认您无条件授权佰易国际在您的借币到期或超级杠杆账户发生风险时采取代为减仓，乃至完全平仓等风险控制的操作，而无需对您承担任何责任。</p>
  <p>3.1.5当您使用超级杠杆交易时，应当遵守国家相关法律，保证交易资产的来源合法合规。您不得利用超级杠杆交易从事任何违反您所属、所居住、开展经营活动或其他业务、或对您有税务管辖权的国家或地区的法律法规的行为。有关违法行为包括但不限于洗钱。</p>
  <p>3.1.6当您使用超级杠杆交易时，应当充分认识到数字资产投资的风险以及超级杠杆交易的风险，谨慎操作，量力而行。</p>
  <p>3.1.7您同意在佰易国际所进行的所有投资操作代表您的真实投资意愿，并无条件接受投资决策所带来的潜在风险和收益。</p>
  <p>3.1.8您理解在借币及超级杠杆交易时可能产生手续费等相关费用，并同意按照平台不时公布的要求缴纳相应费用。</p>
  <p>3.1.9您同意佰易国际在超级杠杆账户发生风险时保留自行对账户实施减仓，平仓，自动还款等风险控制操作的权利与权限且无需对您或任何第三方承担任何责任，并无条件接受最终的成交结果。</p>
  <p>3.1.10 佰易国际保留暂停，终止借币、超级杠杆交易业务的权限，在必要的时候，平台可以随时暂停，终止借币、超级杠杆交易业务。</p>
  <p>3.2永续合约风险提示与确认。</p>
  <p>3.2.1数字资产自身存在风险。数字资产价格易产生波动，无涨跌停限制，并在全球范围内一周7天、一天24小时无休止交易，其价格容易受到庄家控制以及全球新闻事件、各国政策、市场需求等多种因素影响，可能出现一天价格涨几倍的情况也可能出现一天内价格跌去一半的情况，由于永续合约的高杠杆性，您可能遭受较大的损失，因而我们强烈建议您在自身所能承受的风险范围内参与交易。</p>
  <p>3.2.2在意外因素的影响下，如系统故障、网络原因、拒绝服务攻击（DDoS）和其他黑客攻击、异常成交、行情中断、或其他可能的异常情况，我们有权根据实际情况自行取消异常成交结果，以及回滚某一段时间的所有成交，而无需对您或任何第三方承担任何责任。</p>
  <p>3.2.3我们严厉禁止任何不正当的交易行为。我们有权对所有恶意操纵价格，恶意影响交易系统等不道德行为进行警告，并在有必要的时候，自行采用限制交易、暂停交易、取消交易、逆向取消已达成交易、冻结账户、回滚时段交易等手段以消除不良影响，而无需对您或任何第三方承担任何责任。</p>
  <p>3.2.4当您的仓位保证金无法满足平台的要求时将被强制平仓，如果价格波动剧烈，系统在使用所有风险控制方法后仍发生亏损，我们有权向您追回损失。</p>
  <p>3.2.5当您的持仓数量或委托数量过大，我们认为可能对系统和其他用户产生严重风险时，您理解并同意我们有权要求您采用撤单，平仓等风控措施。此外，在我们认为有必要的时候，有权自行对个别账户采用限制总仓位数量、限制总委托数量、限制开仓、撤单或强行平仓等措施进行风险控制，而无需对您或任何第三方承担任何责任。</p>

  <h2>第四章 交易管理及费用</h2>
  <p>4.1本平台将为您的交易提供服务，并在服务过程中根据有关文件、协议和/或本平台页面的相关规则、说明等收取必要的服务或管理费用，详情请参阅本协议、本平台相关页面的有关文件、规则和说明。上述内容据此明确纳入本条款，并可能不时被修订。您同意，本平台有权不时调整前述服务或管理费用的类型或金额等具体事项并根据本协议和相关规则进行公告、修改。如您继续接受本平台服务即视为您同意更新后的有关条款。</p>

  <h2>第五章 服务变更、中断或终止</h2>
  <p>5.1除非本平台单方面终止本协议或者您申请终止本协议且经本平台同意，否则本协议始终有效。若您违反了本协议、相关规则、任何法律或法规，或我们合理怀疑你在使用我们的服务的过程中涉及参与非法或不当行为，或在政府部门的要求下，本平台有权自行终止本协议、关闭您的账户或者限制您使用本平台，而无需对您承担任何责任。但本平台的终止行为不能免除您根据本协议或在本平台生成的其他协议项下的还未履行完毕的义务。</p>
  <p>5.2若您发现有第三人冒用或盗用您的用户账户及密码，或其他任何未经合法授权的情形，应立即以有效方式通知本平台，要求本平台暂停相关服务。因使用您的帐户（无论是否属于授权使用）而产生或与之有关的一切责任、损失、损害、索赔、费用或开支，均由您承担。</p>
  <p>5.3鉴于网络服务的特殊性，您同意本平台有权随时变更、中断或终止部分或全部的网络服务，而无需另行通知您，也无需对任何您或任何第三方承担任何责任。</p>
  <p>5.4您理解，本平台需要定期或不定期地对提供网络服务的平台（如互联网网站、移动网络等）或相关的设备进行检修或者维护，如因此类情况而造成网络服务在合理时间内的中断，本平台会尽可能及时发出通知，但无需承担由此而引起的任何损失、损害、赔偿或责任。</p>
  <p>5.5本平台有权自行判断决定暂停、中断或终止向您提供本协议项下的全部或部分服务，将注册资料移除或删除，或采取任何补救或临时措施（包括但不限于取消、撤销交易和账户冻结），无需作出通知，也无需对您或任何第三方承担任何责任。在不影响前述权利广泛性的前提下，我们可能会在下列情况下行使该权利：</p>
  <p>（1）本平台认为您提供的个人资料不具有真实性、有效性或完整性；</p>
  <p>（2）本平台发现或怀疑您存在异常交易、非法交易或不寻常的活动时；</p>
  <p>（3）本平台认为您的账户涉嫌洗钱、套现、传销、被冒用或其他本平台认为有风险之情形；</p>
  <p>（4）本平台认为您已经违反本协议；</p>
  <p>（5）您在使用收费网络服务时未按规定向本平台支付相应的服务费；</p>
  <p>（6）本平台发现您的帐户遭到未经授权的访问，或您的帐户受到政府程序、刑事/监管调查或任何未决诉讼的限制；</p>
  <p>（7）本平台自行判断的其他需暂停、中断或终止向您提供本协议项下的全部或部分服务并将注册资料移除或删除的其他情形。</p>
  <p>5.6您同意，对您账户的暂停、中断、终止或我们基于前述条款采取的其他任何措施，将不会解除您的责任，您仍应对您使用本平台服务期间的行为承担可能的违约、损害赔偿或任何其他责任，同时本平台仍可保有您的相关信息。</p>
  <p>5.7如您注册的免费网络服务的账号在任何连续90日内未实际使用，则本平台有权删除该账号并停止为您提供相关的网络服务。</p>

  <h2>第六章 使用规则</h2>
  <p>6.1【账户资料内容规范】</p>
  <p>（1）您在申请使用平台服务时，应按照本平台相关规则要求提供准确的个人资料，如个人资料有任何变动，您应及时更新。</p>
  <p>（2）您不应将其账号、密码转让或出借予他人使用。如您发现其账号遭他人非法使用，应立即通知平台。因病毒、黑客行为或您的保管疏忽导致账号、密码遭他人非法使用，本平台不承担任何责任。</p>
  <p>6.2【服务运营规范】</p>
  <p>6.2.1您应当遵守法律法规、规章、规范性文件及政策要求的规定，保证账户中所有数字货币来源的合法性。除非法律允许或本平台书面许可，您使用平台及相关服务过程中不得从事下列行为：</p>
  <p>（1）利用本平台服务进行任何可能对互联网或移动网络正常运转造成不利影响的行为；</p>
  <p>（2）利用平台提供的网络服务上传、展示或传播任何虚假的、骚扰性的、中伤他人的、辱骂性的、恐吓性的、庸俗淫秽、暴力的或其他任何违反法律法规规定的信息资料、言论；</p>
  <p>（3）利用平台服务系统进行任何不利于本平台的行为；</p>
  <p>（4）侵害第三方名誉权、肖像权、知识产权、商业秘密等合法权利或侵犯任何人的商业利益；</p>
  <p>（5） 诱导其他用户点击链接页面或分享信息。未经平台书面许可利用平台账号和任何功能，以及第三方运营平台进行推广，或发布非经本平台许可的商业广告；</p>
  <p>（6）制作、发布与以上行为相关的方式、工具，或对此方式、工具进行运营或传播，无论这些行为是否为商业目的；</p>
  <p>（7）其他违反或可能违反法律法规、侵犯任何第三方权利、干扰平台正常运营的行为。</p>
  <p>6.2.2您承诺遵守所有本平台数字货币交易规则，包括但不限于：</p>
  <p>（1）浏览交易信息</p>
  <p>您在本平台浏览数字货币交易信息时，应当仔细阅读交易信息中包含的全部内容，包括但不限于数字货币价格、委托量、手续费、买入或卖出方向，您完全接受交易信息中包含的全部内容后方可点击按钮进行交易。</p>
  <p>（2）提交委托</p>
  <p>您在浏览完交易信息确认无误之后可以提交交易委托。您提交交易委托后，即您授权本平台代理您进行相应的交易撮合，本平台在有满足您委托价格的交易时将会自动完成撮合交易而无需提前通知您。</p>
  <p>（3）查看交易明细</p>
  <p>您可以通过账户交易明细查看相应的成交记录，确认自己的详情交易记录。</p>
  <p>（4）撤销/修改委托</p>
  <p>在匹配交易未达成之前，您有权随时撤销或修改委托。</p>
  <p>6.3本平台有权对您使用平台服务的情况进行审查和监督（包括但不限于对您存储在平台的内容进行审核)，如您在使用平台服务时违反任何上述规定，本平台有权要求您改正或补救（如有可能），也有权直接采取一切必要的措施（包括但不限于更改或删除您张贴的内容、暂停或终止您使用网络服务的权利），以减轻您的行为造成的影响。</p>
  <p>6.4如果市场价格在您的订单范围之内，通常在正常操作期间您在佰易国际下的订单将被执行。但是，即使市场价格在您下达或以其他方式打开时的价格在您的范围之内，我们也不保证能够执行您的订单。若您在佰易国际计划内或计划外停机期间在佰易国际下单，一旦我们恢复运营将在商业上合理的基础上进行处理。 佰易国际保留拒绝或取消停机期间已下订单和/或未下订单的权利。</p>
  <p>6.5订单可能受制于佰易国际无法控制的延误、困难和/或条件而影响到订单的传输或执行，包括但不限于机械或电子故障或市场拥堵，佰易国际对此不承担任何责任。</p>

  <h2>第七章 知识产权</h2>
  <p>7.1 除另有规定外，本平台上的所有内容均为佰易国际的财产，受版权、专利、商标及其他适用法律保护。</p>
  <p>7.2 本平台使用之佰易国际商标、商品名称、服务商标及公司徽标均为佰易国际及其各自所有者的财产。本网站及平台所使用的软件、应用程序、文字、图像、图形、数据、价格、交易、图表、图形、视听资料均属于佰易国际所有。本平台商标和其他内容不得以任何形式或方式被复制、再制、修改、重印、上载、张贴、传送、抓取、收集或散布，无论是通过自动或手动实现。</p>
  <p>7.3严禁在任何其他网站或网络计算机环境中，为任何其他目的使用我们平台的任何内容；任何此类未经授权的使用都可能违反版权、专利、商标和任何其他适用法律，并可能招致刑事或民事处罚。</p>
  <p>7.4 佰易国际为本平台的商标，未经平台的书面授权，任何用户或者第三方不得使用。</p>
  <p>7.5 佰易国际支持知识产权保护。如果您希望就您持有的有效注册商标或服务标志的侵权行为提出商标主张，或希望就您持有真正版权的材料提出版权主张，请发送电子邮件至  support@100ex.com。</p>

  <h2>第八章 隐私保护</h2>
  <p>您一旦注册、登录、使用本平台服务，将视为您完全了解、同意并接受本平台隐私协议。</p>

  <h2>第九章 免责声明</h2>
  <p>您理解本平台允许您使用我们的服务，向您提供相关服务，使您能够购买、出售或存储数字资产，均不构成也不应被您理解为向您提供投资建议。本平台不提供投资建议、税务建议，法律咨询，或其他专业建议。我们不推荐和/或支持你购买或出售数字资产和/或任何投资。在从事任何交易或投资活动之前，你应咨询合格的专业人士。</p>
  <p>我们通过佰易国际向您提供的服务是严格按照“按现状”、“如有”及“已有”的基础提供。公司不就佰易国际或其中包含的信息或服务的准确性、完整性、及时性、非侵权性、可销售性、针对特定用途的适用性作出陈述或保证。在任何情况下，本公司概不对您或任何其他人因使用佰易国际及其服务或其中的信息而采取的任何决定或行动造成的损失或损害承担责任。无论该情况是因：信息不准确或不完整，延迟、中断、错误或遗漏而造成的损失；或因疏忽或意外情况造成公司在控制范围之外信息提取、编译、解释、计算、报告、或交付而造成的任何损失或损害；或因本平台所载的数据或向用户提供的产品或服务有所遗漏而导致的任何损失或损害，而不论造成该等成因的情况是否在本公司。</p>
  <p>本公司概不会对用户或任何其他人士就直接、特殊、间接、相应或附带损害或任何形式的其他任何损害（包括直接或间接利润损失）承担任何责任（不论与侵权或合约有关），即使本公司或任何其他有关人士已获告知其可能性。此责任限制包括但不限于传播可能感染用户设备的任何病毒、机械或电子设备或通讯线路故障、电话或其他互连问题、未经授权进入、盗窃、操作员错误、罢工或其他劳工问题或任何不可抗力。公司无法亦不会保证您能够持续、不间断或安全地进入佰易国际。</p>

  <h2>第十章 风险提示</h2>
  <p>10.1数字货币市场是全新的、未经确认的，而且可能不会增长；</p>
  <p>10.2数字货币主要由投机者大量使用，零售和商业市场使用相对较少，数字货币交易存在极高风险，其24小时不间断交易、无涨跌限制，价格容易受政府政策等因素影响而大幅波动；</p>
  <p>10.3因各国法律、法规和规范性文件的制定或者修改，数字货币交易随时可能被暂停或被禁止；</p>
  <p>10.4数字货币交易有极高风险，您了解和理解此投资有可能导致部分损失或全部损失，所以您应该以能承受的损失程度来决定投资的金额。您了解和理解数字货币会产生衍生风险，所以如有任何疑问，建议先寻求理财顾问的协助。此外，除了上述提及过的风险以外，还会有未能预测的风险存在。您应慎重考虑并用清晰的判断能力去评估自己的财政状况及上述各项风险而作出任何买卖数字货币的决定，并承担由此产生的全部损失，本平台对此不承担任何责任。</p>

  <h2>第十一章 违约赔偿</h2>
  <p>如因您违反有关法律、规则、法规、第三方权利、本协议项下的任何内容或因您使用平台提供的全部或部分服务而引致或造成任何索赔、要求、诉讼、损害、损失、成本或费用（包括但不限于合理的律师费），均由您承担，您同意就此向本平台作出赔偿、为本平台抗辩并维护本平台免受损害。</p>

  <h2>第十二章 通知送达</h2>
  <p>12.1 本协议项下的通知如以公示方式作出，一经在本平台公示即视为已经送达。除此之外，其他向您个人发布的具有专属性的通知将由本平台向您在注册时提供的电子邮箱，或本平台在您的个人账户中为您设置的站内消息系统栏，或您在注册后在本平台绑定的手机发送，一经发送即视为已经送达。请您密切关注您的电子邮箱、站内消息系统栏中的邮件、信息及手机中的短信信息。</p>
  <p>12.2 您同意本平台出于向您提供服务之目的，可以向您的电子邮箱、站内消息系统栏和手机发送有关通知或提醒；若您不愿意接收，请在本平台相应系统板块进行设置。但您同时同意并确认，若您设置了不接收有关通知或提醒，则您有可能收不到该等通知信息，您不得以您未收到或未阅读该等通知信息主张相关通知未送达于您。</p>

  <h2>第十三章 向法定机构和认可金融机构进行披露</h2>
  <p>13.1在以下情况下，我们可能会与执法机构、数据保护机构、政府官员或其他机构分享您的个人数据：</p>
  <p>13.1.1 根据法律规定；</p>
  <p>13.1.2 受传票、法院命令或其他法律程序所迫；</p>
  <p>13.1.3 我们认为披露信息对于防止损害或财务损失是必要的；</p>
  <p>13.1.4 举报涉嫌违法行为需要披露；</p>
  <p>13.1.5 披露对于调查违反本协议的行为是必要的。</p>

  <h2>第十四章 适用法律和管辖</h2>
  <p>本条款受相关法律管辖并按其解释。法院拥有专属管辖权解决任何因本协议所引起的或与之相关的任何争议、纠纷、分歧或索赔，包括协议的存在、效力、解释、履行、违反或终止，或因本协议引起的或与之相关的任何非合同性争议。。</p>

  <h2>第十五章 其他约定</h2>
  <p>本平台对本协议在法律许可的范围内拥有最终的解释权。本协议及本平台有关页面的相关名词可互相引用参照，如有不同理解，则以本协议协议为准。此外，若本协议的部分协议被认定为无效或者无法实施时，本协议中的其他协议仍然有效。</p>
  <p>如果这些条款与您可能与佰易国际达成的任何其他协议之间存在任何冲突，则仅当这些条款被明确标识并声明被其他协议所取代时，该另一协议的条款才有效。</p>
  <p>任何佰易国际未能执行或延迟执行本条款或行使本协议项下的权利，均不应被视为对我方对权利的放弃。</p>
  <p>如本协议内容与英文版本有任何冲突，以英文版本为准。</p>
</div>
      `,  
    },

    'en-us': {
      /* ===== Top nav ===== */
      nav_market: 'Market',                                      nav_market_url: 'https://www.100ex.com/en/market',
      nav_spot: 'Spot Trading',
      nav_spot_basic: 'Spot',                                    nav_spot_basic_url: 'https://www.100ex.com/trade?tradeType=1',
      nav_spot_margin: 'Margin',                                 nav_spot_margin_url: 'https://www.100ex.com/margin/BTC_USDT',
      nav_spot_grid: 'Grid',                                     nav_spot_grid_url: 'https://www.100ex.com/trade?tradeType=3',
      nav_futures: 'Futures',                                    nav_futures_url: 'https://futures.100ex.com',
      nav_c2c: 'C2C Trading',
      nav_c2c_normal: 'Normal Trade',                            nav_c2c_normal_url: 'https://otc.100ex.com/C2C',
      nav_c2c_ad: 'Post Ad',                                     nav_c2c_ad_url: 'https://otc.100ex.com/C2C/merchant/publishAd',
      nav_c2c_merchant: 'Apply as Merchant',                     nav_c2c_merchant_url: 'https://otc.100ex.com/C2C/applyMerchant',
      nav_finance: 'Finance',                                    nav_finance_url: 'https://www.100ex.com/finance',
      nav_byb: 'BYB Zone',                                       nav_byb_url: 'https://www.100ex.com/BYB',
      nav_loan: 'Loans',                                         nav_loan_url: 'https://www.100ex.com/toLoan',
      nav_switch_lang: 'Language',

      header_welcome: 'Welcome to',
      header_title: 'BYEX Help Center',
      header_search_placeholder: 'Search or ask a question',

      self_service_title: 'Self-Service',
      more: 'More >',
      self_service_more_url: 'selfservice.html',
      faq_more_url: '#',
      chat_support_card_url: '#',

      /* cards (kept) */
      service_card_1_title: 'Registration & Download Guide',      service_card_1_url: 'article.html?article=42474568545945',
      service_card_1_desc: 'iOS/Android download tutorial and registration process.',
      service_card_1_desc_mobile: 'iOS/Android download & registration.',
      service_card_2_title: 'Account Security',                  service_card_2_url: '#',
      service_card_2_desc: 'Bind email/phone, set password, enable Google Authenticator.',
      service_card_2_desc_mobile: 'Bind email/phone, set password.',
      service_card_3_title: 'Identity Verification',             service_card_3_url: '#',
      service_card_3_desc: 'Submit ID documents to enhance account level and security.',
      service_card_3_desc_mobile: 'Enhance account security.',
      service_card_4_title: 'Deposit & Withdrawal',              service_card_4_url: '#',
      service_card_4_desc: 'Issues like on-chain confirmation time, arrival errors, minimum limits.',
      service_card_4_desc_mobile: 'Deposit/withdrawal issues.',
      service_card_5_title: 'Code & Authenticator Issues',       service_card_5_url: '#',
      service_card_5_desc: 'Solutions for not receiving codes, resetting Google Authenticator.',
      service_card_5_desc_mobile: 'Verification code & GA issues.',
      service_card_6_title: 'Trading Guide',                     service_card_6_url: '#',
      service_card_6_desc: 'Trading procedures for Spot, Futures, etc., including fund transfers.',
      service_card_6_desc_mobile: 'Spot, Futures trading guide.',
      service_card_7_title: 'Futures Q&A',                       service_card_7_url: '#',
      service_card_7_desc: 'Core concepts like contracts, margin, funding rate, ROI.',
      service_card_7_desc_mobile: 'Margin, funding rate concepts.',
      service_card_8_title: 'Promotions & Rewards',              service_card_8_url: '#',
      service_card_8_desc: 'Latest promotions, participation conditions, and reward distribution.',
      service_card_8_desc_mobile: 'Latest promotions and rewards.',
      service_card_9_title: 'C2C Trading',                       service_card_9_url: '#',
      service_card_9_desc: 'C2C buying/selling process, order risk control, and appeals.',
      service_card_9_desc_mobile: 'C2C process and risk control.',
      service_card_10_title: 'Batch Transfer',                   service_card_10_url: '#',
      service_card_10_desc: 'Supports batch internal transfers by UID for multi-account fund allocation.',
      service_card_10_desc_mobile: 'Batch internal transfers by UID.',
      service_card_11_title: 'Financial Products',               service_card_11_url: '#',
      service_card_11_desc: 'Participation methods and rules for flexible, fixed, and other products.',
      service_card_11_desc_mobile: 'Flexible, fixed savings, etc.',
      service_card_12_title: 'Crypto Loans',                     service_card_12_url: '#',
      service_card_12_desc: 'Use crypto assets as collateral to obtain USDT loan quotas.',
      service_card_12_desc_mobile: 'Get USDT loans with crypto.',
      service_card_13_title: 'Referral Program',                 service_card_13_url: '#',
      service_card_13_desc: 'Invite friends to earn commissions, view referral records and ratios.',
      service_card_13_desc_mobile: 'Invite friends to earn commissions.',
      service_card_14_title: 'Fees & Rates',                     service_card_14_url: '#',
      service_card_14_desc: 'Fee standards for maker/taker, deposit/withdrawal, futures, etc.',
      service_card_14_desc_mobile: 'Maker/taker, deposit/withdrawal fees.',

      faq_title: 'Frequently Asked Questions',
      faq_popular: 'Popular Questions',
      faq_latest: 'Latest Articles',

      guide_wallet_title: 'BYEX Wallet Guide',                   guide_wallet_more_url: '#',
      guide_wallet_1: 'Intro to Pro Wallet Mode',                guide_wallet_1_url: '#',
      guide_wallet_2: 'How to Use the Wallet',                   guide_wallet_2_url: '#',
      guide_kyc_title: 'Identity Verification',                  guide_kyc_more_url: '#',
      guide_kyc_1: 'How to Complete Personal KYC',               guide_kyc_1_url: '#',
      guide_kyc_2: 'Full Process for Enterprise KYC',            guide_kyc_2_url: '#',
      guide_c2c_title: 'BYEX C2C Intro',                         guide_c2c_more_url: '#',
      guide_c2c_1: 'Introduction to C2C Trading',                guide_c2c_1_url: '#',
      guide_c2c_2: 'Withdrawal Limit Explanation',               guide_c2c_2_url: '#',
      guide_security_title: 'Security Guide',                    guide_security_more_url: '#',
      guide_security_1: '2FA Security Tips',                     guide_security_1_url: '#',
      guide_security_2: 'How to Prevent Phishing',               guide_security_2_url: '#',
      announcements_title: 'Announcements',                      announcements_more_url: '#',
      announcements_1: 'New Coin & Pair Listings',               announcements_1_url: '#',
      announcements_2: 'Latest BYEX News',                       announcements_2_url: '#',
      announcements_3: 'Latest BYEX Promotions',                 announcements_3_url: '#',
      announcements_4: 'New Fiat & Pair Listings',               announcements_4_url: '#',

      more_help_title: 'Need More Help?',
      more_help_chat_title: 'Chat Support',
      more_help_chat_desc: 'If you have any questions, feel free to contact us. Our chat support team is available 24/7.',
      more_help_chat_cta: 'Learn More',

      /* Footer */
      footer_community: 'Community',
      footer_about: 'About Us',
      footer_about_1: 'About Us',                                footer_about_1_url: 'https://100ex.zendesk.com/hc/p/about',
      footer_about_2: 'User Agreement',                          footer_about_2_url: 'https://100ex.zendesk.com/hc/p/UserAgreement',
      footer_about_3: 'Disclaimer',                              footer_about_3_url: 'https://100ex.zendesk.com/hc/p/Disclaimer',
      footer_about_4: 'Privacy Policy',                          footer_about_4_url: '#',
      footer_about_5: 'Contact Us',                              footer_about_5_url: '#',
      footer_products: 'Products',
      footer_products_1: 'Exchange',                             footer_products_1_url: '#',
      footer_products_2: 'Payment Wallet',                       footer_products_2_url: '#',
      footer_products_3: 'C2C Trading',                          footer_products_3_url: '#',
      footer_products_4: 'BYB Staking',                          footer_products_4_url: '#',
      footer_services: 'Services',
      footer_services_1: 'Fee Schedule',                         footer_services_1_url: '#',
      footer_services_2: 'Referral',                             footer_services_2_url: '#',
      footer_services_3: 'BYB Zone',                             footer_services_3_url: '#',
      footer_services_4: 'Announcements',                        footer_services_4_url: '#',
      footer_services_5: 'Merchant Service Agreement',           footer_services_5_url: '#',
      footer_learn: 'Learn',
      footer_learn_1: 'Beginner\'s Guide',                       footer_learn_1_url: '#',
      footer_learn_2: 'Blockchain Basics',                       blockchain_basics_url: '#',
      footer_learn_3: 'Blockchain Glossary',                     blockchain_glossary_url: '#',
      footer_risk: 'Risk & Compliance',
      footer_risk_1: 'Risk Disclosure',                          risk_disclosure_url: '#',
      footer_risk_2: 'Irregular Trading Policy',                 irregular_trading_url: '#',
      footer_risk_3: 'Margin Parameters',                        margin_parameters_url: '#',
      footer_copyright: '© 2025 BYEX. All rights reserved.',
      language_modal_title: 'Language',
      select_language: 'Select Language',
      loading: 'Loading...',
      no_articles: 'No articles found.',
      load_fail: 'Failed to load articles.',
      no_section_id: 'Please set one or more Section IDs in the code.',

      /* Community */
      'community.social_title': 'Social Channels',
      'community.official_title': 'Official Channels',
      'community.subtitle': 'Join the conversation and get the latest updates!',
      'community.pill_exchange': 'Exchange',

      'community.card_en_title': 'English',
      'community.card_zh_title': 'Chinese',
      'community.card_announce_title': 'Announcements',

      'community.open_tg_text': 'Open Telegram group',

      'community.copy_tip': 'Click to copy',
      'community.copied': 'Copied',
      'community.copy_fail': 'Copy failed',

      /* Labels */
      'community.label.telegram': 'Telegram',
      'community.label.tiktok': 'TikTok',
      'community.label.facebook': 'Facebook',
      'community.label.x': 'X',
      'community.label.instagram': 'Instagram',
      'community.label.cmc': 'CoinMarketCap',
      'community.label.youtube': 'YouTube',

      /* Alt */
      'community.alt.telegram': 'Telegram',
      'community.alt.tiktok': 'TikTok',
      'community.alt.facebook': 'Facebook',
      'community.alt.x': 'X',
      'community.alt.instagram': 'Instagram',
      'community.alt.cmc': 'CoinMarketCap',
      'community.alt.youtube': 'YouTube',

      /* Links for community page */
      'community.link.telegram_url': 'https://100ex.zendesk.com/hc/p/community',
      'community.link.tiktok_url': 'https://www.tiktok.com/@byexchange?_t=ZS-8yhEGR0HNlw&_r=1',
      'community.link.facebook_url': 'https://www.facebook.com/share/172nzHGGLz/?mibextid=wwXIfr',
      'community.link.x_url': 'https://x.com/100EXOfficial',
      'community.link.instagram_url': 'https://www.instagram.com/byex_exchange/?igsh=MTk2bnN0YTJ3dGl4dw%3D%3D&utm_source=qr#',
      'community.link.cmc_url': 'https://coinmarketcap.com/exchanges/byex/',
      'community.link.youtube_url': 'https://www.youtube.com/@BYEXOfficial',

      'community.en_url': 'https://t.me/BYEX_Official',
      'community.zh_url': 'https://t.me/byex',
      'community.announce_url': 'https://t.me/baiyi',

      /* Footer social (locale-specific) */
      'footercommunity.link.telegram_url': 'https://100ex.zendesk.com/hc/en-us/p/community',
      'footercommunity.link.tiktok_url':   'https://www.tiktok.com/@byexchange?_t=ZS-8yhEGR0HNlw&_r=1',
      'footercommunity.link.facebook_url': 'https://www.facebook.com/share/172nzHGGLz/?mibextid=wwXIfr',
      'footercommunity.link.x_url':        'https://x.com/100EXOfficial',
      'footercommunity.link.instagram_url':'https://www.instagram.com/byex_exchange/?igsh=MTk2bnN0YTJ3dGl4dw%3D%3D&utm_source=qr#',
      'footercommunity.link.cmc_url':      'https://coinmarketcap.com/exchanges/byex/',
      'footercommunity.link.youtube_url':  'https://www.youtube.com/@BYEXOfficial',

      /* top-subnav */
      'community.topnav.about': 'About Us',
      'community.topnav.about_url': 'https://100ex.zendesk.com/hc/p/about',
      'community.topnav.community': 'Community',
      'community.topnav.community_url': 'https://100ex.zendesk.com/hc/p/community',

      /* About page */
      'about.title': 'Introduction',
      'about.lead': 'BYEX is a leading digital asset platform that provides seamless and secure solutions for trading, managing, and storing digital assets. Founded with the vision of bridging the gap between traditional finance and blockchain technology, our platform was created to empower users with innovative financial solutions. Recognizing the increasing demand for digital asset management, we embarked on this journey to offer a comprehensive, user-friendly, and secure ecosystem that caters to individuals, institutions, and enterprises looking to leverage blockchain technology for financial growth and asset management.',
      'about.hero_img_alt': 'BYEX overview',

      'about.mission_title': 'Mission',
      'about.mission_desc': 'Our mission is to facilitate access to digital assets by providing a secure, transparent, and user-friendly platform that fosters financial empowerment for all.',
      'about.vision_title': 'Vision',
      'about.vision_desc': 'To be one of the world’s most trusted and innovative digital asset platforms, enabling seamless interaction with blockchain technology and decentralized finance.',

      'about.values_title': 'Core Values',
      'about.values.security_title': 'Security',
      'about.values.security_desc': 'Protect user assets and data.',
      'about.values.transparency_title': 'Transparency',
      'about.values.transparency_desc': 'Operate clearly, openly, and with integrity.',
      'about.values.innovation_title': 'Innovation',
      'about.values.innovation_desc': 'Deliver cutting-edge digital asset solutions.',
      'about.values.ease_title': 'Ease of Use',
      'about.values.ease_desc': 'Making digital assets easy to use, regardless of expertise',
      'about.values.customer_title': 'Customer-Centricity',
      'about.values.customer_desc': 'Provide excellent user experience and support.',

      'about.services_title': 'Key Offerings',
      'about.services.trade_title': 'Digital Asset Trading',
      'about.services.trade_desc': 'Buy and sell crypto and digital assets easily.',
      'about.services.wallet_title': 'Wallet Service',
      'about.services.wallet_desc': 'Secure and user-friendly digital wallets for storing assets safely',
      'about.services.stake_title': 'Staking & Yield',
      'about.services.stake_desc': 'Earn passive income through staking and yield farming.',
      'about.services.institution_title': 'Institutional Services',
      'about.services.institution_desc': 'Customized liquidity and C2C solutions.',

      /* —— Unified Technology & Security —— */
      'shared.security.title': 'Technology & Security',
      'shared.security.desc': 'Our platform is built with robust security frameworks, including multi-factor authentication (MFA), encryption, cold storage solutions, and real-time monitoring to ensure the highest level of asset protection. We comply with industry regulations and best practices to provide a safe and legally compliant trading environment.',

      'about.why_title': 'Why BYEX?',
      'about.why.ui_title': 'Intuitive Interface',
      'about.why.ui_desc': 'More efficient trading and asset management.',
      'about.why.security_title': 'Top-tier Security',
      'about.why.security_desc': 'Protect assets across the entire flow.',
      'about.why.fee_title': 'Competitive Fees',
      'about.why.fee_desc': 'Trade more cost-effectively.',
      'about.why.support_title': '24/7 Support',
      'about.why.support_desc': 'We’re here anytime, anywhere.',
      'about.why.defi_title': 'Blockchain & DeFi',
      'about.why.defi_desc': 'Cutting-edge features with ongoing updates.',

      'about.cta_title': 'Join BYEX and unlock new opportunities',
      'about.cta_desc': 'Experience a secure, transparent, and easy-to-use platform now.',
      'about.cta_btn': 'Go to Trade',
      'about.cta_url': 'https://www.100ex.com',

/* ===== Disclaimer (EN) ===== */
'disclaimer.title': 'Disclaimer',
'disclaimer.updated_label': 'Last updated：',
'disclaimer.updated_value': 'July 12 , 2019',
'disclaimer.content': `
<p>This disclaimer should be read with the Terms of Service of the “BYEX International Service Agreement” and the “BYEX International Privacy Agreement”. Simply put, we want you to understand the important risk and compliance issues associated with trading on our platform.</p>

<h2>Purpose</h2>
<p>The purpose of this website is to provide professional, safe and reliable digital asset trading and asset management services for digital asset enthusiasts, stock enthusiasts and users around the world as much as possible without violating relevant laws and regulations. We are committed to promoting legal and transparent business activities and maintaining a good reputation among users, regulators and the digital asset industry.</p>

<h2>Business Model</h2>
<p>We are a global digital asset trading platform, or marketplace, where traders come to trade as buyers and sellers, often referred to as makers and takers. For clarity, the buyer and seller trade with each other; BYEX International is not involved in the actual transaction. Users can log in to <a href="https://www.100ex.com" target="_blank" rel="noopener">www.100ex.com</a> and its related API or mobile application (“Website”) to obtain services provided by BYEX International.</p>
<p><strong>Disclosure:</strong> Trading is risky. The risk of loss in trading or holding digital assets can be substantial. Therefore, you should carefully consider whether trading is suitable for you in light of your financial situation.</p>

<h2>Regulatory Environment</h2>
<p>Digital assets are not money or legal tender. Digital assets such as Bitcoin and Litecoin are not backed by any government or central bank. While we may comment on regulatory approaches adopted by various government agencies from time to time, we will always fully comply with the rules and regulations of the countries in which we operate and regularly discuss with regulators and peers best practices for regulating digital asset businesses. In addition, BYEX International does not accept certain customers. To maintain market reputation and ensure compliance, if your jurisdiction clearly prohibits digital asset transactions or is listed among sanctioned countries, you must not use the services under this Website.</p>

<h2>Geographical Restrictions</h2>
<p>According to our terms of use, if you are located, incorporated, or otherwise a citizen or resident of any of the following countries or regions, you are not permitted to access or use our platform and services. Restricted countries/regions include:</p>

<ul class="ua-dot">
  <li>Guam</li>
  <li>Puerto Rico</li>
  <li>U.S. Virgin Islands</li>
  <li>North Korea</li>
  <li>Cuba</li>
  <li>Iran</li>
  <li>Mainland China</li>
  <li>Belarus</li>
  <li>Crimea</li>
  <li>Democratic Republic of the Congo</li>
  <li>Iraq</li>
  <li>Sudan</li>
  <li>Syria</li>
  <li>South Sudan</li>
  <li>Samoa</li>
  <li>Panama</li>
  <li>Venezuela</li>
</ul>

<p>Please note that additional jurisdictions may also be subject to partial restrictions.</p>

<p>We cooperate with government authorities and comply with applicable regulations. Law enforcement may request information, and where permitted by law we will assist investigations to track and stop illegal activity. This also means our platform is only available to law-abiding clients. We hope to serve you, and we also expect lawful conduct on our platform.</p>
<p>The entire content of this agreement is concluded in accordance with relevant laws; its formation, interpretation, content and performance are governed by applicable laws and regulations. If users violate the law due to breach of this statement, the Website—as a service provider—will maintain and improve platform rules and services; however, the Website has no motive or fact of violating the law and assumes no joint liability for users’ actions.</p>

<h2>Our AML/CTF Program</h2>
<p>Through a risk-based multi-level control framework, our Anti-Money Laundering and Counter-Terrorism Financing program is designed to reasonably prevent money laundering and terrorist financing.</p>
<p>The program includes strict customer identification procedures for individuals and entities. In addition to obtaining identification documents, we also obtain information about beneficial owners of institutional (non-natural person) users.</p>
<p>We conduct continuous monitoring for suspicious activity. If we suspect or have reason to suspect suspicious trading, we may at our discretion file suspicious activity reports with local regulators. Typically, suspicious transactions are inconsistent with a customer’s known legitimate business or routine behavior.</p>
<p>Anyone who logs in to this Website or directly/indirectly uses its services is deemed to have voluntarily accepted this statement.</p>

<h2>Risk</h2>
<div>
  <p><span class="idx">5.1</span> Digital-asset transactions are considered high risk. Digital assets are not backed by any government or central bank. Consider carefully whether interacting with, holding, or trading digital assets is suitable for you based on your financial situation.</p>
  <p><span class="idx">5.2</span> Under any and all circumstances, BYEX International shall not be liable for punitive, indirect, incidental, special or consequential losses arising from use of the platform, including without limitation personal injury, loss of business profits, transaction interruptions, loss of business information or any other related losses.</p>
  <p><span class="idx">5.3</span> There is risk of loss in investing in securities or financial products, and BYEX International will not bear responsibility for losses caused by customers’ investment activities.</p>
  <p><span class="idx">5.4</span> Due to malicious Internet attacks, server failures and other unpredictable factors, market or other securities-related information may be wrong or delayed.</p>
  <p><span class="idx">5.5</span> To the extent permitted by law, BYEX International and its affiliates expressly disclaim any direct, indirect, special, incidental, consequential or punitive damages arising out of or related to individuals or entities based on information contained on the BYEX International app special loss or damage, including but not limited to any errors or omissions in the information contained on the BYEX International App, and any responsibility or legal liability to anyone.
The above information:
(1) For informational purposes only.
(2) does not constitute a recommendation for any financial product.
(3) Unless expressly authorized, it shall not be reproduced or redistributed.
(4) Can be withdrawn from time to time.
The above information is not intended and does not constitute an offer or solicitation to buy or sell any financial instrument. The value and income corresponding to the investment may rise or fall. Past performance is no guarantee of future performance.</p>
  <p><span class="idx">5.6</span> Customers’ devices or software may be illegally attacked or infected by viruses, resulting in failure to place orders.</p>
  <p><span class="idx">5.7</span> If a customer’s device/system is incompatible with BYEX International’s online trading system causing inability to place orders or order failures, customers can contact support for assistance; however, BYEX International cannot guarantee financial compensation for failures caused by uncontrollable circumstances.</p>
</div>

<h2>Other Agreements</h2>
<p>This platform reserves the final right of interpretation to the extent permitted by law. If these statements conflict with any other agreement you may have with BYEX International, applicable laws and regulations shall prevail.</p>
</div>
      `,  

      /* ===== User Agreement (EN) ===== */
	  'user_agreement.title': 'User Agreement',
  'user_agreement.updated_label': 'Last updated：',
  'user_agreement.updated_value': 'July 12 , 2019',
  'user_agreement.content': `
<div class="ua-rich">
  <p>BYEX International and its affiliated companies (hereinafter collectively referred to as the "Company" or "BYEX International") jointly operate the website: www.100ex.com and related mobile applications (hereinafter referred to as "the platform" or "this platform"), And based on this platform, it provides users with trading between digital currencies and related services. For the purpose of this Agreement, affiliate means another entity that controls, is controlled by, or is under common control with, directly or indirectly through one or more intermediaries. If you register as a user of this platform, you agree to accept this agreement and be bound by all agreements published on the platform and all policies published on the website (hereinafter referred to as the "agreement"). If you do not accept the following agreement, please immediately stop registering, stop visiting the website, and/or stop using the services, products or content of this platform.</p>

  <h2>I、 Revision of the Agreement：</h2>
  <p>1.1 You declare and ensure that you are over 18 years old, have full capacity for civil conduct as required by law, and have not been deprived of the right to use our services. If you do not meet the above conditions, please do not register on our website or platform, otherwise the company reserves the right to suspend or terminate your account at any time.</p>
  <p>1.2 Your conclusion and performance of this agreement shall not be prohibited by the laws and regulations of the country or region to which you belong, reside, conduct business activities or other businesses, or have tax jurisdiction over you. If you do not meet the aforementioned conditions, you should immediately terminate the registration or stop using the services of this platform.</p>
  <p>1.3 You follow the prompts on the platform page to complete the entire registration process or use the related services of the platform each time, which means that you fully understand and accept all the contents of this agreement (including subsequent revisions made from time to time and published on the platform) Agreement). The content of this agreement includes all agreements under this agreement and various rules that have been issued or may be issued by this platform in the future. All various rules that have been released or may be released in the future are expressly incorporated and constitute an integral part of this agreement, and have the same legal effect as the text of the agreement.</p>
  <p>1.4 The platform has the right to modify this agreement from time to time as needed or to formulate and modify various specific rules in accordance with this agreement and publish them on the relevant system sections of the platform without separately notifying you. You should pay attention to changes in this agreement and specific rules from time to time. If you continue to use this service after the announcement of changes in this agreement and specific rules, it is deemed that you have fully read, understood and accepted the revised agreement and specific rules. The services of this platform will also be used in accordance with the revised agreement and specific rules.</p>
  <p>1.5 Accepting this agreement or operating your account (whether personally or through others) to access the relevant services of this platform in accordance with this agreement and the relevant rules and instructions of the platform is deemed to be a legal agreement between you and BYEX International potency. This agreement does not involve legal relationships or legal disputes (if any) arising from network services or trading between you and other users of this platform.</p>
  <p>1.6 You agree that BYEX International may immediately terminate your access to this platform and account by issuing a notice, including but not limited to the following rights: restricting, suspending or terminating services and user accounts, prohibiting access to the platform and its content, services and tools, Delay or delete content, take technical and legal measures to remove users who infringe or violate this agreement and platform policies from the platform, and any further measures to make up for any loss or damage caused, once we determine in our sole discretion that you may violate any laws, regulations, The rights of third parties, or any content of this agreement or platform policy. BYEX International shall not be liable for any loss or damage caused to you or any third party as a result of exercising your rights under these terms.</p>

  <h2>II、Service Content and Your Rights and Obligations：</h2>
  <p>2.1 BYEX International provides you with digital asset trading services. This platform does not act as a buyer or seller for direct trading with users, and does not provide services related to the deposit and withdrawal of any national legal currency.</p>
  <p>2.1.1 You have the right to browse the real-time digital currency market and trading information on the platform, and have the right to submit digital currency trading instructions and complete digital currency trading through the platform.</p>
  <p>2.1.2 You have the right to view the information under your account on the platform, and have the right to operate using the functions provided by the platform.</p>
  <p>2.1.3 You have the right to participate in the website activities organized by the platform in accordance with the activity rules issued by the platform, as well as other services promised by the platform.</p>
  <p>2.2 You understand and agree that the platform can adjust the service content, service types and service forms on the platform at any time according to the actual situation. The platform is not responsible for any negative impact or loss caused to you or any third party due to platform adjustments.</p>
  <p>2.3 Depending on your country/region, you may not be able to use all the functions of this website or platform. We have the right to suspend the provision of certain services to users in specific countries, but ensure that laws and regulations are observed when accessing this website, platform and using our services (including where you live and/or when you access this website) country laws and regulations) are your responsibility.</p>
  <p>2.4 In order to access and use our services, you must create an account with BYEX International. You agree to:</p>
  <p>(1) Provide accurate, current and complete information when creating an account;</p>
  <p>(2) Maintain and promptly update your account information to keep it accurate, complete and current;</p>
  <p>(3) Maintain the security and confidentiality of your login credentials and restrict access to your account and computer;</p>
  <p>(4) If you discover or suspect any security breaches related to the platform, you should immediately notify FX International;</p>
  <p>(5) Be responsible for all activities that occur under your account and bear all risks of unauthorized access;</p>
  <p>2.5 In order to provide services to you, the platform may reasonably use your user personal information, non-personal information and information provided by third parties (hereinafter collectively referred to as "user information"). Once you register, log in, and use the services of this platform, it will be deemed that you fully understand, agree and accept that the company reasonably uses user information through methods including but not limited to collection, statistics, analysis, and so on.</p>
  <p>2.6 You confirm that the trading status confirmed by you on this platform according to the service process of this platform will become a clear instruction for this platform to carry out relevant trading or operations for you. You agree that this platform has the right to deal with relevant matters in accordance with this agreement and/or relevant documents and rules in accordance with relevant instructions.</p>
  <p>2.7 Any disputes or losses caused by your failure to modify or confirm the trading status in a timely manner or fail to submit relevant applications shall be borne by you, and this platform shall not bear any responsibility.</p>

  <h2>III、Risk Reminder and Confirmation：</h2>
  <p>3.1 Risk reminder and confirmation of loan and super leveraged trading：</p>
  <p>3.1.1 BYEX International launches currency lending service to provide you with long/short super leveraged trading services.</p>
  <p>3.1.2 Your maximum loan amount is determined by the maximum loan multiple.</p>
  <p>3.1.3 BYEX International provides risk management services for borrowing your super leveraged trading, and monitors and manages your super leveraged accounts in BYEX International.</p>
  <p>3.1.4 When you use super leveraged trading, it means that you unconditionally authorize BYEX International to take risk control operations such as reducing positions or even completely closing positions when your loan expires or when risks occur in your super leveraged account. You assume no liability.</p>
  <p>3.1.5 When you use super leveraged trading, you should abide by relevant national laws and ensure that the source of trading assets is legal and compliant. You shall not use super leveraged trading to engage in any behavior that violates the laws and regulations of the country or region where you belong, reside, conduct business activities or other business, or have tax jurisdiction over you. Relevant violations include, but are not limited to, money laundering.</p>
  <p>3.1.6 When you use super leveraged trading, you should be fully aware of the risks of digital asset investment and super leveraged trading, operate with caution and do what you can.</p>
  <p>3.1.7 You agree that all investment operations in BYEX International represent your true investment wishes, and you unconditionally accept the potential risks and benefits brought about by investment decisions.</p>
  <p>3.1.8 You understand that related fees such as handling fees may be incurred during borrowing and super leveraged trading, and agree to pay the corresponding fees in accordance with the requirements announced by the platform from time to time.</p>
  <p>3.1.9 You agree that BYEX International reserves the right and authority to implement risk control operations such as reducing positions, closing positions, and automatic repayments on the account when risks occur in the super leveraged account, and it does not need to bear any responsibility for you or any third party, unconditionally accept the final trading result.</p>
  <p>3.1.10 BYEX International reserves the right to suspend and terminate the lending and super leveraged trading. When necessary, the platform can suspend and terminate the borrowing and super leveraged trading business at any time.</p>
  <p>3.2 Perpetual contract risk reminder and confirmation.</p>
  <p>3.2.1 Digital assets have their own risks. The price of digital assets is prone to fluctuations, there is no price limit, and it is traded 24 hours a day, 7 days a week around the world. Its price is easily affected by various factors such as banker control, global news events, national policies, market demand, etc., the price may increase several times in one day, or the price may fall by half in one day. Due to the high leverage of perpetual contracts, you may suffer relatively large losses. Participate in trading within the risk range.</p>
  <p>3.2.2 Under the influence of unexpected factors, such as system failures, network reasons, denial of service attacks (DDoS) and other hacker attacks, abnormal trading, market interruptions, or other possible abnormal situations, we have the right to cancel the exception according to the actual situation trading results, and roll back all trading for a certain period of time without any liability to you or any third party.</p>
  <p>3.2.3 We strictly prohibit any improper trading. We have the right to warn against all unethical behaviors such as maliciously manipulating prices and maliciously affecting the trading system, and when necessary, adopt restrictions on trading, suspension of trading, cancellation of trading, reverse cancellation of completed trading, freezing accounts, and rollback periods trading and other means to eliminate adverse effects without any liability to you or any third party.</p>
  <p>3.2.4 When your position margin cannot meet the requirements of the platform, you will be forced to close the position. If the price fluctuates violently and the system still suffers losses after using all risk control methods, we have the right to recover the losses from you.</p>
  <p>3.2.5 When your number of positions or orders is too large, and we believe that there may be serious risks to the system and other users, you understand and agree that we have the right to require you to take risk control measures such as canceling orders and closing positions. In addition, when we think it is necessary, we have the right to control the risk of individual accounts by taking measures such as limiting the total number of positions, limiting the total number of orders, limiting the opening of positions, canceling orders or forced liquidation, without requiring you or any third party The third party assumes no responsibility.</p>

  <h2>IV、Trading Management and Fees：</h2>
  <p>4.1 The platform will provide services for your trading, and will charge necessary service or management fees in accordance with the relevant documents, agreements and/or relevant rules and instructions on the platform page during the service process. For details, please refer to this agreement, relevant information on this platform Documentation, rules and instructions on the page. The foregoing is hereby expressly incorporated into these Terms, as may be amended from time to time. You agree that this platform has the right to adjust specific matters such as the type or amount of the aforementioned services or management fees from time to time, and to make announcements and modifications in accordance with this agreement and relevant rules. If you continue to accept the services of this platform, you are deemed to agree to the updated terms.</p>

  <h2>V、Service Change, Interruption or Termination：</h2>
  <p>5.1 Unless this platform unilaterally terminates this agreement or you apply for termination of this agreement and this agreement is agreed by this platform, this agreement will always be valid. If you violate this agreement, relevant rules, any laws or regulations, or we reasonably suspect that you are involved in illegal or improper behavior during the use of our services, or at the request of government departments, this platform has the right to terminate this service agreement, closing your account or restricting your use of the Platform without any liability to you. However, the termination of this platform does not exempt you from your unfulfilled obligations under this agreement or other agreements generated on this platform.</p>
  <p>5.2 If you find that a third party has fraudulently used or stolen your user account and password, or any other unauthorized situation, you should immediately notify this platform in an effective manner and request this platform to suspend relevant services. All liabilities, losses, damages, claims, costs or expenses arising out of or in connection with the use of your account (whether authorized or not) are borne by you.</p>
  <p>5.3 In view of the particularity of network services, you agree that this platform has the right to change, interrupt or terminate some or all of the network services at any time without further notice to you, and without any liability to you or any third party.</p>
  <p>5.4 You understand that this platform needs to regularly or irregularly overhaul or maintain the platform that provides network services (such as Internet websites, mobile networks, etc.) or related equipment, if such circumstances cause network services to be interrupted within a reasonable time , the platform will issue notices in a timely manner as much as possible, but it does not need to bear any loss, damage, compensation or responsibility arising therefrom.</p>
  <p>5.5 The platform has the right to decide at its sole discretion to suspend, interrupt or terminate all or part of the services provided to you under this agreement, to remove or delete the registration information, or to take any remedial or temporary measures (including but not limited to canceling, revoking the transaction and account freezing) without notice and without any liability to you or any third party. Without prejudice to the breadth of the aforementioned rights, we may exercise this right in the following circumstances:</p>
  <p>(1) The platform believes that the personal information you provide is not authentic, valid or complete;</p>
  <p>(2) When this platform discovers or suspects that you have abnormal transactions, illegal transactions or unusual activities;</p>
  <p>(3) The platform believes that your account is suspected of money laundering, cash-out, pyramid schemes, fraudulent use or other situations that the platform considers risky;</p>
  <p>(4) The platform believes that you have violated this agreement;</p>
  <p>(5) When you use paid network services, you fail to pay the corresponding service fees to the platform as required;</p>
  <p>(6) The platform finds that your account has been accessed without authorization, or your account is subject to government procedures, criminal/regulatory investigations or any pending litigation;</p>
  <p>(7) Other circumstances that require the suspension, interruption or termination of all or part of the services provided to you under this agreement and the removal or deletion of registration information as determined by the platform at its own discretion.</p>
  <p>5.6 You agree that the suspension, interruption, termination of your account or any other measures we take based on the foregoing clauses will not relieve you of your responsibilities, and you should still be responsible for possible breach of contract and damages for your actions during the use of the platform services or any other responsibility, while the platform can still retain your relevant information.</p>
  <p>5.7 If your registered free network service account has not been actually used within 90 consecutive days, this platform has the right to delete the account and stop providing you with relevant network services.</p>

  <h2>VI、Rules of Use：</h2>
  <p>6.1 [Account Data Content Specifications]</p>
  <p>(1) When you apply to use platform services, you should provide accurate personal information in accordance with the relevant rules of this platform. If there is any change in your personal information, you should update it in time.</p>
  <p>(2) You should not transfer or lend your account and password to others. If you find that your account has been illegally used by others, you should notify the platform immediately. This platform does not assume any responsibility for the illegal use of account numbers and passwords by others due to viruses, hacking or your negligence in storage.</p>
  <p>6.2 [Service Operation Specifications]</p>
  <p>6.2.1 You shall abide by laws, regulations, normative documents and policy requirements, and ensure the legitimacy of all digital currency sources in your account. Unless permitted by law or with the written permission of this platform, you shall not engage in the following acts when using the platform and related services:</p>
  <p>(1) Use the services of this platform to conduct any behavior that may adversely affect the normal operation of the Internet or mobile network;</p>
  <p>(2) Use the network services provided by the platform to upload, display or disseminate any false, harassing, slanderous, abusive, threatening, vulgar, obscene, violent or any other information that violates laws and regulations, remarks;</p>
  <p>(3) Use the platform service system to conduct any behavior that is not conducive to the platform;</p>
  <p>(4) Infringe on the third party's legal rights such as reputation rights, portrait rights, intellectual property rights, and trade secrets, or infringe on anyone's commercial interests;</p>
  <p>(5) Inducing other users to click on linked pages or share information. Using the platform account and any functions without the written permission of the platform, as well as third-party operating platforms for promotion, or publishing commercial advertisements not authorized by the platform;</p>
  <p>(6) Produce and publish methods and tools related to the above acts, or operate or disseminate such methods and tools, regardless of whether these acts are for commercial purposes or not;</p>
  <p>(7) Other acts that violate or may violate laws and regulations, infringe the rights of any third party, or interfere with the normal operation of the platform.</p>
  <p>6.2.2 You promise to abide by all the digital currency transaction rules of this platform, including but not limited to:</p>
  <p>(1) Browse transaction information</p>
  <p>When you browse the digital currency transaction information on this platform, you should carefully read all the content contained in the transaction information, including but not limited to digital currency price, entrusted amount, handling fee, buying or selling direction, and you fully accept that the transaction information contains Click the button to trade after all the content.</p>
  <p>(2) Submit entrustment</p>
  <p>You can submit a transaction order after browsing the transaction information and confirming that it is correct. After you submit the transaction entrustment, you authorize the platform to act on your behalf to carry out the corresponding transaction matching. When there is a transaction that meets your entrusted price, the platform will automatically complete the matching transaction without prior notice to you.</p>
  <p>(3) View transaction details</p>
  <p>You can check the corresponding transaction records through the account transaction details to confirm your detailed transaction records.</p>
  <p>(4) Revocation/modification of entrustment</p>
  <p>Before the matching transaction is reached, you have the right to revoke or modify the order at any time.</p>
  <p>6.3 This platform has the right to review and supervise your use of platform services (including but not limited to reviewing the content you store on the platform). If you violate any of the above regulations when using platform services, this platform has the right to require you to Correction or remedy (if possible), also has the right to directly take all necessary measures (including but not limited to changing or deleting the content you posted, suspending or terminating your right to use network services) to mitigate the impact of your actions.</p>
  <p>6.4 If the market price is within the range of your order, usually during normal operation, the order you place with BYEX International will be executed. However, we do not guarantee that your order will be executed even if the market price at the time you place or otherwise open it is within your range. If you place an order with B&E International during a planned or unplanned outage of B&E International, it will be processed on a commercially reasonable basis once we resume operations. BYEX International reserves the right to refuse or cancel orders placed and/or not placed during the downtime.</p>
  <p>6.5 Orders may be subject to delays, difficulties and/or conditions beyond the control of BYEX International that affect the transmission or execution of orders, including but not limited to mechanical or electronic failures or market congestion, for which BYEX International is not responsible.</p>

  <h2>VII、Intellectual Property Rights：</h2>
  <p>7.1 Unless otherwise specified, all content on this platform is the property of BYEX International and is protected by copyright, patent, trademark and other applicable laws.</p>
  <p>7.2 The trademarks, product names, service marks and company logos of BYEX International used on this platform are the property of BYEX International and their respective owners. The software, applications, text, images, graphics, data, prices, transactions, charts, graphics, and audio-visual materials used on this website and platform belong to BYEX International. Trademarks and other content on this platform may not be copied, reproduced, modified, reprinted, uploaded, posted, transmitted, crawled, collected or distributed in any form or by any means, whether by automatic or manual means.</p>
  <p>7.3 Use of any content on our platform for any other purpose on any other website or in a networked computer environment is strictly prohibited; any such unauthorized use may violate copyright, patent, trademark and any other applicable laws and may result in criminal or civil penalties.</p>
  <p>7.4 BYEX International is a trademark of this platform, and no user or third party may use it without the written authorization of the platform.</p>
  <p>7.5 BYEX International supports the protection of intellectual property rights. If you wish to make a trademark claim for infringement of a valid registered trademark or service mark that you hold, or if you wish to make a copyright claim for material in which you hold the bona fide copyright, please contact us by online service.</p>

  <h2>VIII、Privacy Protection：</h2>
  <p>Once you register, log in, and use the services of this platform, it will be deemed that you fully understand, agree and accept the privacy agreement of this platform.</p>

  <h2>VIIII、Disclaimer：</h2>
  <p>You understand that this platform allows you to use our services, provides you with related services, enables you to buy, sell or store digital assets, neither constitutes nor should be understood by you as providing you with investment advice. This platform does not provide investment advice, tax advice, legal advice, or other professional advice. We do not recommend and/or endorse the purchase or sale of digital assets and/or any investments by you. Before engaging in any trading or investment activity, you should consult a qualified professional.</p>
  <p>The services we provide to you through BYEX International are provided strictly on an "as is", "as available" and "as available" basis. COMPANY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE ACCURACY, COMPLETENESS, TIMELINESS, NON-INFRINGEMENT, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR THE INFORMATION OR SERVICES CONTAINED HEREIN. In no event shall the Company be liable to you or any other person for any loss or damage caused by any decision or action taken by you or any other person as a result of using BYEX International and its services or the information therein. Whether the event is due to: inaccurate or incomplete information, delays, interruptions, errors or omissions; or due to negligence or unforeseen circumstances outside the company's control The extraction, compilation, interpretation, calculation, reporting, or any loss or damage caused by delivery; or any loss or damage caused by omission of data contained in this platform or products or services provided to users, regardless of whether the circumstances of the cause are in the company or not.</p>
  <p>In no event shall the Company be liable to the user or any other person for direct, special, indirect, consequential or incidental damages or any other damages of any kind (including direct or indirect loss of profits), whether in tort or contract, even if The Company or any other relevant person has been advised of its possibility. This limitation of liability includes, but is not limited to, transmission of any viruses that may infect user equipment, failure of mechanical or electronic equipment or communication lines, telephone or other interconnection problems, unauthorized entry, theft, operator error, strikes or other labor problems or any force majeure. The company cannot and will not guarantee your continued, uninterrupted or secure access to BES.</p>

  <h2>X、Risk Warning：</h2>
  <p>10.1 The digital currency market is new, unconfirmed, and may not grow;</p>
  <p>10.2 Digital currency is mainly used by speculators in large quantities, and is relatively less used in retail and commercial markets. Digital currency transactions are extremely risky. Its 24-hour uninterrupted transactions, no price limit, and prices are easily affected by government policies and other factors. Large fluctuations ;</p>
  <p>10.3 Due to the enactment or modification of laws, regulations and normative documents of various countries, digital currency transactions may be suspended or prohibited at any time;</p>
  <p>10.4 Digital currency transactions are extremely risky. You understand and understand that this investment may result in partial or total loss, so you should decide the amount of investment based on the degree of loss you can bear. You understand and understand that digital currency will generate derivative risks, so if you have any questions, it is recommended to seek the assistance of a financial advisor first. In addition, in addition to the risks mentioned above, there will be risks that cannot be predicted. You should carefully consider and use clear judgment to assess your own financial situation and the above-mentioned risks before making any decision to buy or sell digital currency, and bear all losses arising therefrom. This platform does not assume any responsibility for this.</p>

  <h2>XI、Compensation for Breach of Contract：</h2>
  <p>Any claims, demands, actions, damages, losses, costs or All expenses (including but not limited to reasonable attorney's fees) shall be borne by you, and you agree to indemnify, defend and defend this platform from damages to this platform.</p>

  <h2>XII、Service of Notice：</h2>
  <p>12.1 If the notice under this agreement is made by publicity, once it is publicized on this platform, it will be deemed to have been delivered. In addition, other exclusive notices issued to you personally will be provided by the platform to the email address you provided when you registered, or the message system column in the station that the platform sets for you in your personal account, or you in After registration, the mobile phone bound to this platform is sent, once sent, it is deemed to have been delivered. Please pay close attention to your email, emails and messages in the message system column of the site, and text messages in your mobile phone.</p>
  <p>12.2 You agree that for the purpose of providing services to you, this platform may send relevant notices or reminders to your email, message system bar and mobile phone; if you do not want to receive, please set up in the corresponding system section of this platform. However, you also agree and confirm that if you have set not to receive relevant notices or reminders, you may not receive such notices, and you may not claim that relevant notices have not been delivered because you have not received or read such notices to you.</p>

  <h2>XIII、Disclosure to Statutory Bodies and Authorized Financial Institutions：</h2>
  <p>13.1 We may share your personal data with law enforcement agencies, data protection agencies, government officials or others in the following circumstances:</p>
  <p>13.1.1 as required by law;</p>
  <p>13.1.2 compelled by subpoena, court order or other legal process;</p>
  <p>13.1.3 We believe disclosure is necessary to prevent damage or financial loss;</p>
  <p>13.1.4 Disclosure is required for reporting suspected illegal activities;</p>
  <p>13.1.5 Disclosure is necessary to investigate violations of this Agreement.</p>

  <h2>XIV、Applicable Law and Jurisdiction：</h2>
  <p>These Terms are governed by and construed in accordance with applicable laws. The court shall have exclusive jurisdiction to resolve any dispute, dispute, disagreement or claim arising out of or in connection with this agreement, including the existence, validity, interpretation, performance, breach or termination of the agreement, or any non-contractual disputes related thereto. .</p>

  <h2>XV、Other Agreements：</h2>
  <p>This platform has the final right to interpret this agreement within the scope permitted by law. The relevant terms in this agreement and the relevant pages of this platform can be referred to each other. If there is any difference in understanding, this agreement shall prevail. In addition, if part of this agreement is deemed invalid or unenforceable, other agreements in this agreement will still be valid.</p>
  <p>If there is any conflict between these Terms and any other agreement you may have with BYEX International, the terms of that other agreement will only be effective if these Terms are expressly identified and stated to be superseded by the other agreement.</p>
  <p>Any failure or delay by BYEX International to enforce this clause or exercise its rights under this Agreement shall not be deemed a waiver of our rights.</p>
  <p>In case of any conflict between the content of this Agreement and the English version, the English version shall prevail.</p>
</div>
      `,  
    },    
};

// 支持语言
const languages = [
  { code: 'zh-cn', name: '简体中文' },
  { code: 'en-us', name: 'English' }
];

/* ===== 工具：就绪 ===== */
function tReady(fn){
  if (document.readyState !== 'loading') { try{fn();}catch(e){console.error(e);} }
  else document.addEventListener('DOMContentLoaded', function onDom(){
    document.removeEventListener('DOMContentLoaded', onDom);
    try{fn();}catch(e){console.error(e);}
  });
}

/* ===== 当前语言 ===== */
function tGetLocale(){
  const m = location.pathname.match(/\/hc\/([a-z\-]+)(?:\/|$)/i);
  const fromPath = (m && m[1]) ? m[1] : '';
  const lc = (fromPath ||
              (window.HelpCenter && (window.HelpCenter.user?.locale || window.HelpCenter.locale)) ||
              'en-us');
  return String(lc).toLowerCase().replace('_','-');
}

/* ===== 键名别名（含 URL 别名）===== */
const KEY_ALIASES = {
  // Header
  nav_spot_classic: ['nav_spot_basic'],
  nav_margin:       ['nav_spot_margin'],
  nav_grid:         ['nav_spot_grid'],
  nav_spot_trading: ['nav_spot'],
  lang_switch:      ['nav_switch_lang', 'language_modal_title'],

  // C2C 下拉
  c2c_trade:            ['nav_c2c_normal'],
  c2c_post_ad:          ['nav_c2c_ad'],
  c2c_apply_merchant:   ['nav_c2c_merchant'],

  // Footer URL 别名
  footer_learn_2: ['blockchain_basics'],
  footer_learn_3: ['blockchain_glossary'],
  footer_risk_1:  ['risk_disclosure'],
  footer_risk_2:  ['irregular_trading'],
  footer_risk_3:  ['margin_parameters'],

  // 兼容旧“技术与安全”键名 → 统一到 shared.security.*
  'about.security_title': ['shared.security.title'],
  'about.security_desc':  ['shared.security.desc']
};

/* ===== 取文案（含英文兜底）===== */
function tPick(dict, key){
  if (!dict) return '';
  if (key in dict) return dict[key];
  const aliases = KEY_ALIASES[key] || [];
  for (const k of aliases){ if (k in dict) return dict[k]; }
  const en = translations['en-us'] || translations['en'] || {};
  if (key in en) return en[key];
  for (const k of aliases){ if (k in en) return en[k]; }
  return '';
}

/* ===== 取 URL（兼容传入已带 _url 的键）===== */
function tPickUrl(dict, key){
  const isFull = key.endsWith('_url');
  const base   = isFull ? key.slice(0, -4) : key;

  // 1) 直接取 base_url
  let v = tPick(dict, base + '_url');
  if (v) return v;

  // 2) 如果传进来本身就是 *_url，也试一下原键名
  if (isFull) {
    v = tPick(dict, key);
    if (v) return v;
  }

  // 3) 别名尝试
  const aliases = KEY_ALIASES[base] || [];
  for (const ak of aliases){
    v = tPick(dict, ak + '_url');
    if (v) return v;
  }

  // 4) 英文兜底
  const en = translations['en-us'] || {};
  return en[base + '_url'] || (isFull ? en[key] || '' : '');
}

/* ===== 应用到 DOM ===== */
function applyTranslations(){
  const lc   = tGetLocale();
  const dict = translations[lc] || translations['en-us'] || {};

  // 1) 文本（含富文本）
  document.querySelectorAll('[data-translate-key]').forEach(el=>{
    const key = el.getAttribute('data-translate-key');
    if (!key) return;
    const text = tPick(dict, key);
    if (!text) return;

    // 简单判断是否富文本：键名以 .content 结尾或值里包含标签
    const isRich = /\.content$/.test(key) || /<\w+[\s>]/.test(text);
    if (isRich) el.innerHTML = text;
    else el.textContent = text;
  });

  // 2) 属性映射
  document.querySelectorAll('[data-translate-attr]').forEach(el=>{
    const spec = el.getAttribute('data-translate-attr');
    if (!spec) return;
    spec.split(';').forEach(pair=>{
      const [attr, key] = pair.split(':').map(s=>s && s.trim());
      if (!attr || !key) return;
      const val = tPick(dict, key);
      if (val) el.setAttribute(attr, val);
    });
  });

  // 3) href（兼容 data-translate-href 或 data-translate-href-key，且兼容 *_url）
  document.querySelectorAll('a[data-translate-href], a[data-translate-href-key]').forEach(a=>{
    let key = a.getAttribute('data-translate-href-key') || a.getAttribute('data-translate-href');
    if (!key){
      const span = a.querySelector('[data-translate-key]'); // 如果是包了一个 span
      key = span ? span.getAttribute('data-translate-key') : '';
    }
    if (key){
      const url = tPickUrl(dict, key);
      if (url) a.setAttribute('href', url);
    }
  });

  // 4) Footer 语言文字兜底
  const langItem = (languages || []).find(l=>l.code === lc);
  const langName = langItem?.name || (lc.startsWith('zh') ? '简体中文' : 'English');
  const f1 = document.getElementById('footer-language-text');
  const f2 = document.getElementById('footer-language-text-mobile');
  if (f1 && !f1.textContent) f1.textContent = langName;
  if (f2 && !f2.textContent) f2.textContent = langName;

  // 5) 搜索占位符	
  const input = document.querySelector('input[type="search"]');
  const ph = tPick(dict, 'header_search_placeholder');
  if (input && ph) input.setAttribute('placeholder', ph);
}

/* ===== 启动 & 暴露 ===== */
tReady(applyTranslations);
window.__applyTranslations = applyTranslations;
window.translations = translations;
window.languages = languages;

/* ===== 本页锚点平滑滚动（只拦截 a.js-scroll 的 # 链接）===== */
tReady(function(){
  document.querySelectorAll('a.js-scroll[href^="#"]').forEach(a=>{
    a.addEventListener('click', function(e){
      const id = a.getAttribute('href').slice(1);
      const target = document.getElementById(id);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
});
})();
