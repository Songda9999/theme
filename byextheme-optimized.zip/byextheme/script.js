/* ========= 通用工具 ========= */
function ready(fn) {
  if (document.readyState !== 'loading') {
    try { fn(); } catch (e) { console.error(e); }
  } else {
    document.addEventListener('DOMContentLoaded', function onDomReady() {
      document.removeEventListener('DOMContentLoaded', onDomReady);
      try { fn(); } catch (e) { console.error(e); }
    });
  }
}

/* ========= 语言工具 ========= */

/** 获取当前 HC 语言（统一为 zh-cn / en-us） */
function getCurrentHcLocale() {
  const lc = (window.HelpCenter && (window.HelpCenter.user?.locale || window.HelpCenter.locale)) || 'en-us';
  return String(lc).toLowerCase().replace('_', '-');
}

/** 支持语言列表（优先 HelpCenter.locales 注入；否则调 API；最后兜底） */
let __localeCache = null;
async function getSupportedLocalesAsync() {
  if (__localeCache) return __localeCache;

  const injected = (window.HelpCenter && window.HelpCenter.locales) || [];
  const normalizedInjected = injected.map(l => String(l).toLowerCase().replace('_', '-')).filter(Boolean);
  if (normalizedInjected.length) {
    __localeCache = Array.from(new Set(normalizedInjected));
    return __localeCache;
  }

  try {
    const res = await fetch('/api/v2/help_center/locales.json', { credentials: 'same-origin' });
    if (!res.ok) throw new Error('fetch locales failed');
    const data = await res.json();
    const arr = Array.isArray(data) ? data : (Array.isArray(data.locales) ? data.locales : []);
    const normalized = arr.map(l => String(l).toLowerCase().replace('_', '-')).filter(Boolean);
    __localeCache = normalized.length ? Array.from(new Set(normalized)) : ['zh-cn', 'en-us'];
  } catch (e) {
    __localeCache = ['zh-cn', 'en-us'];
  }
  return __localeCache;
}

/** 语言显示名（优先自定义，失败用 Intl） */
function prettyName(locale) {
  const lc = String(locale || '').toLowerCase();
  const override = {
    'zh-cn': '简体中文',
    'zh-tw': '繁體中文',
    'en-us': 'English (US)',
    'en-gb': 'English (UK)',
    'en': 'English'
  };
  if (override[lc]) return override[lc];

  try {
    const ui = getCurrentHcLocale();
    const [lang, region] = lc.split('-');
    const langNames = new Intl.DisplayNames([ui], { type: 'language', languageDisplay: 'standard' });
    const regionNames = new Intl.DisplayNames([ui], { type: 'region' });
    let name = langNames.of(lang) || lc;
    if (region) {
      const rn = regionNames.of(region.toUpperCase());
      if (rn) name = `${name}（${rn}）`;
    }
    return name;
  } catch {
    return lc;
  }
}

/** 生成切换到目标语言的 HC URL（替换 /hc/{locale}/ 片段） */
function buildHcLocaleUrl(targetLocale) {
  const parts = window.location.pathname.split('/');
  const i = parts.findIndex(p => p === 'hc');
  if (i >= 0 && parts[i + 1]) parts[i + 1] = targetLocale;
  return parts.join('/') + window.location.search + window.location.hash;
}

/** 切换语言：先改写 data-translate-href，再淡出页面跳转（带兜底） */
function switchLanguage(targetLocale) {
  if (!targetLocale) return;

  // 1) 外链 zh_CN / en_US 规范化
  const mapUrl = (lang) =>
    String(lang).toLowerCase().replace('-', '_')
      .replace(/^([a-z]{2})_([a-z]{2})$/i, (m, a, b) => `${a}_${b.toUpperCase()}`);
  const newLangForHref = mapUrl(targetLocale);

  // 2) 改写所有 data-translate-href 的链接语言段
  document.querySelectorAll('[data-translate-href]').forEach((el) => {
    const href = el.getAttribute('href') || '';
    if (!href) return;
    const updated = href.replace(/\/[a-z]{2}_[A-Z]{2}\//g, `/${newLangForHref}/`);
    el.setAttribute('href', updated);
  });

  // 3) 生成目标地址
  const dest = buildHcLocaleUrl(targetLocale);
  const normalize = (u) => String(u || '').replace(/\/+$/, '');

  // 与当前地址一致 -> 不做淡出
  if (normalize(dest) === normalize(window.location.href)) return;

  // 4) 页面淡出 + 导航（带失败回滚）
  const root = document.documentElement;
  try {
    // 先解除滚动锁（如果来自弹窗）
    document.body.classList.remove('hc-scroll-lock');

    // 做一次渲染再淡出，避免卡帧
    requestAnimationFrame(() => {
      root.classList.add('hc-fadeout');

      // 记录入场动画，并跳转
      try {
        sessionStorage.setItem('hc_lang_entry', '1');
        sessionStorage.setItem('hc_lang_to', targetLocale);
      } catch (e) {}

      const go = () => { window.location.assign(dest); };
      setTimeout(go, 80);

      // 兜底：1.5s 后还没跳走则撤销淡出，避免“空白可点”
      setTimeout(() => {
        if (normalize(window.location.href) !== normalize(dest)) {
          root.classList.remove('hc-fadeout');
        }
      }, 1500);
    });
  } catch (e) {
    window.location.href = dest;
  }
}

/* ========= 通用辅助（滚动锁 & 清旧 Footer 弹窗） ========= */
function unlockScrollHard() {
  try {
    document.body.style.overflow = '';
    document.body.style.position = '';
    document.body.style.height = '';
    document.documentElement.style.overflow = '';
    document.documentElement.style.height = '';
    document.body.classList.remove('modal-open', 'hc-scroll-lock');
  } catch (e) {}
}

function killLegacyFooterModal() {
  try {
    const legacy = document.getElementById('language-modal'); // 旧 Footer 弹窗
    if (legacy) legacy.remove();
  } catch (e) {}
}

/* 捕获阶段“截胡” Footer 的旧监听器，防它先锁滚动 */
function interceptFooterLangButtons() {
  const ids = ['footer-language-button', 'footer-language-button-mobile'];
  function captureHandler(e) {
    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();

    // 强力解锁 + 移除旧弹窗（多次保险，防延迟加锁）
    unlockScrollHard();
    killLegacyFooterModal();
    setTimeout(unlockScrollHard, 0);
    setTimeout(unlockScrollHard, 80);
    setTimeout(unlockScrollHard, 160);

    // 统一打开新版语言弹窗
    openLangModal();
  }
  ids.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('click',      captureHandler, true); // capture!
    el.addEventListener('touchstart', captureHandler, true); // capture!
  });
}
ready(interceptFooterLangButtons);

/* ========= 语言弹窗（Header & Footer 共用） ========= */
async function openLangModal() {
  // 先清旧 Footer 弹窗，避免“双弹窗”
  killLegacyFooterModal();

  // 打开前强制解锁一次（防旧脚本提前加锁）
  unlockScrollHard();

  // 防重复
  const existed = document.getElementById('lang-modal');
  if (existed) existed.remove();

  const current = getCurrentHcLocale();
  const locales = await getSupportedLocalesAsync();

  // 简体中文排第一
  const ordered = [...locales].sort((a, b) => {
    const n = s => String(s).toLowerCase().replace('_','-');
    const A = n(a), B = n(b);
    if (A === 'zh-cn' && B !== 'zh-cn') return -1;
    if (B === 'zh-cn' && A !== 'zh-cn') return 1;
    return 0;
  });
  const gridCls = ordered.length === 2 ? 'grid grid-cols-2 gap-3' : 'grid grid-cols-1 sm:grid-cols-2 gap-3';

  const modal = document.createElement('div');
  modal.id = 'lang-modal';
  modal.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/50 transition-opacity';
  modal.style.opacity = '0';

  const panel = document.createElement('div');
  panel.className = 'lang-panel w-full max-w-[520px] mx-4 bg-white rounded-2xl shadow-xl transform transition-all';
  panel.style.opacity = '0';
  panel.style.transform = 'scale(0.96)';

  panel.innerHTML = `
    <div class="flex items-center justify-between px-5 py-4 border-b border-gray-200">
      <h3 class="text-lg font-semibold">
        <span class="i18n-zh">语言</span><span class="i18n-en">Language</span>
      </h3>
      <button id="lang-modal-close" class="p-2 text-gray-400 hover:text-gray-600" aria-label="Close">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="px-5 py-5">
      <div class="${gridCls}">
        ${ordered.map(loc => {
          const active = loc === current;
          return `
            <button class="lang-pill px-4 py-4 rounded-xl border ${active ? 'bg-emerald-50 border-emerald-300 text-gray-900' : 'border-gray-200'} text-left" data-locale="${loc}">
              ${prettyName(loc)}
            </button>`;
        }).join('')}
      </div>
    </div>
  `;

  modal.appendChild(panel);
  document.body.appendChild(modal);

  // 打开后，启动一个短期“保险丝”，反复解锁，防旧脚本延迟锁滚
  const unlockPulse = setInterval(unlockScrollHard, 120);

  // 入场动画
  requestAnimationFrame(() => {
    modal.style.opacity = '1';
    panel.style.opacity = '1';
    panel.style.transform = 'scale(1)';
  });

  // —— 允许“直接滚动/滑动”来关闭（和 Header 一致）——
  const closeOnWheel = () => close();
  const closeOnTouchMove = (() => {
    let startY = null;
    return (e) => {
      if (e.type === 'touchstart' && e.touches && e.touches[0]) {
        startY = e.touches[0].clientY;
      } else if (e.type === 'touchmove' && e.touches && e.touches[0] && startY != null) {
        if (Math.abs(e.touches[0].clientY - startY) > 6) close();
      }
    };
  })();

  window.addEventListener('wheel', closeOnWheel, { passive: true });
  window.addEventListener('touchstart', closeOnTouchMove, { passive: true });
  window.addEventListener('touchmove',  closeOnTouchMove, { passive: true });

  function close() {
    if (!document.getElementById('lang-modal')) return;

    // 清保险丝 & 解锁
    clearInterval(unlockPulse);
    unlockScrollHard();

    // 卸载滚动相关监听，防内存泄漏
    window.removeEventListener('wheel',      closeOnWheel);
    window.removeEventListener('touchstart', closeOnTouchMove);
    window.removeEventListener('touchmove',  closeOnTouchMove);

    // 动画关闭
    panel.style.opacity = '0';
    panel.style.transform = 'scale(0.96)';
    modal.style.opacity = '0';
    setTimeout(() => modal.remove(), 140);
  }

  // 顶部 × 按钮、点遮罩、ESC 都能关闭
  panel.querySelector('#lang-modal-close')?.addEventListener('click', close);
  modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); }, { once: true });

  // 选择语言 → 先关弹窗再跳转（避免白屏时遮罩未移除）
  function closeThenNavigate(targetLocale) {
    panel.querySelectorAll('.lang-pill, #lang-modal-close').forEach(b => { b.disabled = true; });
    try {
      sessionStorage.setItem('hc_lang_entry', '1');
      sessionStorage.setItem('hc_lang_to', targetLocale);
    } catch(e) {}
    close();
    setTimeout(() => switchLanguage(targetLocale), 140);
  }
  panel.querySelectorAll('.lang-pill').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const target = btn.getAttribute('data-locale');
      if (target && target !== current) closeThenNavigate(target);
      else close();
    });
  });
}

/* ========= 工具：根据 URL 语言同步 <html> 语言类 ========= */
function syncHtmlLangClass() {
  try {
    var m = location.pathname.match(/\/hc\/([a-z\-]+)(?:\/|$)/i);
    var lc = (m && m[1] ? m[1].toLowerCase() : "");
    if (!lc && window.HelpCenter) {
      lc = String((HelpCenter.user && HelpCenter.user.locale) || HelpCenter.locale || "").toLowerCase();
    }
    var root = document.documentElement;
    root.classList.remove('hc-en','hc-zh');
    root.classList.add(lc.indexOf('zh') === 0 ? 'hc-zh' : 'hc-en');
  } catch (e) {}
}

/* ========= 工具：外链 data-translate-href 跟随站点语言 ========= */
function rewriteAllTranslateHrefs() {
  function currentSiteLocale() {
    var root = document.documentElement;
    if (root.classList.contains('hc-zh')) return 'zh_CN';
    if (root.classList.contains('hc-en')) return 'en_US';
    return 'en_US';
  }
  var siteLocale = currentSiteLocale();
  document.querySelectorAll('a[data-translate-href]').forEach(function (a) {
    var href = a.getAttribute('href') || '';
    if (!href) return;
    if (/\/[a-z]{2}[_-][A-Z]{2}(?=\/|$)/.test(href)) {
      href = href.replace(/\/[a-z]{2}[_-][A-Z]{2}(?=\/|$)/, '/' + siteLocale);
    } else {
      try {
        var u = new URL(href, location.origin);
        if (/100ex\.com$/i.test(u.hostname)) {
          u.pathname = '/' + siteLocale + '/' + u.pathname.replace(/^\//, '');
          href = u.toString();
        }
      } catch (e) {}
    }
    a.setAttribute('href', href);
  });
}

/* ========= Footer 语言按钮文案同步 ========= */
function syncFooterLanguageLabel() {
  const cur = getCurrentHcLocale();
  const text = prettyName(cur);
  const el1 = document.getElementById('footer-language-text');
  const el2 = document.getElementById('footer-language-text-mobile');
  if (el1) el1.textContent = text;
  if (el2) el2.textContent = text;
}

/* ========= 页面就绪 / 交互绑定 ========= */
ready(() => {
  const root = document.documentElement;

  /* ——— 页面就绪态（若 <html> 有 hc-prep，去掉并加 hc-ready） ——— */
  if (root.classList.contains('hc-prep')) {
    root.classList.remove('hc-prep');
    root.classList.add('hc-ready');
  }

  /* ——— 新页面入场动画（语言切换后） ——— */
  try {
    if (sessionStorage.getItem('hc_lang_entry') === '1') {
      sessionStorage.removeItem('hc_lang_entry');
      // 如 head 未预先打 .hc-entering，这里仍给入场动画
      if (!root.classList.contains('hc-entering')) {
        root.classList.add('hc-enter');
        setTimeout(() => root.classList.remove('hc-enter'), 360);
      } else {
        root.classList.remove('hc-entering');
        root.classList.add('hc-enter');
        setTimeout(() => root.classList.remove('hc-enter'), 360);
      }
    }
  } catch (e) {}

  /* ——— 语言类 & 外链语言同步 ——— */
  syncHtmlLangClass();
  rewriteAllTranslateHrefs();
  // 鼠标悬停/点击时再兜底一次，避免动态修改后的链接漏网
  document.addEventListener('mouseover', function (e) {
    if (e.target && e.target.closest('[data-translate-href]')) rewriteAllTranslateHrefs();
  });
  document.addEventListener('click', function (e) {
    if (e.target && e.target.closest('[data-translate-href]')) rewriteAllTranslateHrefs();
  });
  window.addEventListener('popstate', rewriteAllTranslateHrefs);
  window.addEventListener('hashchange', rewriteAllTranslateHrefs);

  /* ——— 同步 Footer 的语言文案 ——— */
  syncFooterLanguageLabel();

  /* ——— 统一语言按钮触发（Header & Footer & Mobile） ——— */
  const langTriggers = [
    document.getElementById('lang-switcher'),
    document.getElementById('lang-toggle'),
    document.getElementById('mobile-lang-toggle'),
    document.getElementById('mobile-lang-row'),                 // 兼容旧版本
    document.getElementById('footer-language-button'),
    document.getElementById('footer-language-button-mobile')
  ].filter(Boolean);

  // 开弹窗前收起移动端菜单（如有）
  function closeMobileMenuIfOpen() {
    const menu = document.getElementById('mobile-menu');
    const btn  = document.getElementById('mobile-menu-button');
    if (menu && menu.classList.contains('open')) {
      menu.classList.remove('open');
      btn && btn.setAttribute('aria-expanded', 'false');
    }
  }

  langTriggers.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      closeMobileMenuIfOpen();
      openLangModal();
    });
  });

  /* ——— 手风琴（桌面小部件 / 移动折叠） ——— */
  // 兼容 .accordion-header 和 .accordion-button 两种命名
  document.querySelectorAll('.accordion-header, .accordion-button').forEach((header) => {
    header.addEventListener('click', () => {
      const content = header.nextElementSibling;
      if (!content) return;
      if (content.style.maxHeight) {
        content.style.maxHeight = null;
        header.classList.remove('active','open');
      } else {
        document.querySelectorAll('.accordion-content').forEach((el) => (el.style.maxHeight = null));
        document.querySelectorAll('.accordion-header, .accordion-button').forEach((el) => el.classList.remove('active','open'));
        content.style.maxHeight = content.scrollHeight + 'px';
        header.classList.add('active','open');
      }
    });
  });

  /* ——— 搜索框 Enter 提交 ——— */
  const searchInput = document.querySelector('input[type="search"]');
  if (searchInput) {
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        searchInput.closest('form')?.submit();
      }
    });
  }

  /* ——— 表单提交加载状态 ——— */
  const form = document.querySelector('form');
  if (form) {
    form.addEventListener('submit', () => {
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML =
          '<svg class="animate-spin h-5 w-5 text-white mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path></svg>';
      }
    });
  }

  /* ========= 移动端菜单（下拉版） ========= */
  const mobileMenuBtn = document.getElementById('mobile-menu-button');
  const mobileMenu    = document.getElementById('mobile-menu');
  const topNav        = document.querySelector('.top-nav');

  if (mobileMenu && mobileMenuBtn) {
    // 兜底：移除残留的 .hidden
    mobileMenu.classList.remove('hidden');

    const openMenu = () => {
      mobileMenu.classList.add('open');
      mobileMenuBtn.setAttribute('aria-expanded', 'true');
    };
    const closeMenu = () => {
      mobileMenu.classList.remove('open');
      mobileMenuBtn.setAttribute('aria-expanded', 'false');
    };
    const toggleMenu = () => {
      mobileMenu.classList.contains('open') ? closeMenu() : openMenu();
    };

    // 点击汉堡
    mobileMenuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleMenu();
    });

    // 菜单内的“会跳转”的链接点击后收起；按钮除非声明 data-close-menu
    mobileMenu.querySelectorAll('a[href]').forEach((el) => el.addEventListener('click', closeMenu));
    mobileMenu.querySelectorAll('button[data-close-menu]').forEach((el) => el.addEventListener('click', closeMenu));

    // 点击 Header 外区域 -> 收起
    document.addEventListener('click', (e) => {
      if (!mobileMenu.classList.contains('open')) return;
      if (topNav && !topNav.contains(e.target)) closeMenu();
    });

    // ESC 关闭
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenu(); });

    // 切回桌面宽度时自动收起
    window.addEventListener('resize', () => { if (window.innerWidth >= 768) closeMenu(); });

    // 移动端二级折叠（现货交易）
    document.querySelectorAll('.mobile-acc-btn').forEach((accBtn) => {
      accBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation(); // 防止误触导致菜单整体收起
        const box  = accBtn.nextElementSibling;     // .mobile-submenu
        const chev = accBtn.querySelector('.chev'); // 箭头
        const show = !box.classList.contains('show');
        box.classList.toggle('show', show);
        if (chev) chev.style.transform = show ? 'rotate(180deg)' : 'rotate(0deg)';
      });
    });
  }
});

/* ========= 再兜底：语言类标记（如极早期脚本未跑） ========= */
ready(syncHtmlLangClass);

/* ========= 软导航（如 #lang-list 里有 <a data-locale>） ========= */
ready(function () {
  function softNavigate(url) {
    var root = document.documentElement;
    root.classList.add('hc-fadeout');
    setTimeout(function () { location.href = url; }, 120);
  }
  var langList = document.getElementById('lang-list');
  if (langList) {
    langList.addEventListener('click', function (e) {
      var a = e.target.closest('a[data-locale]');
      if (!a) return;
      e.preventDefault();
      softNavigate(a.href);
    });
  }
});

/* ========= 移动端菜单（下拉版） ========= */
ready(() => {
  const mobileMenuBtn = document.getElementById('mobile-menu-button');
  const mobileMenu    = document.getElementById('mobile-menu');
  const topNav        = document.querySelector('.top-nav');

  if (!mobileMenu || !mobileMenuBtn || !topNav) return;

  // 兜底：移除残留的 .hidden，防止显示异常
  mobileMenu.classList.remove('hidden');

  const openMenu = () => {
    mobileMenu.classList.add('open');
    mobileMenuBtn.setAttribute('aria-expanded', 'true');
  };
  const closeMenu = () => {
    mobileMenu.classList.remove('open');
    mobileMenuBtn.setAttribute('aria-expanded', 'false');
  };
  const toggleMenu = () => {
    mobileMenu.classList.contains('open') ? closeMenu() : openMenu();
  };

  // 汉堡点击只切换，不拦截后续事件
  mobileMenuBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleMenu();
  });

  // ——重要修复点1：不要给 <a> 绑定 closeMenu，避免 iOS 上导航被提前“打断”——
  // 让链接自己跳走即可；仅对显式要求关闭的按钮保留
  mobileMenu.querySelectorAll('button[data-close-menu]')
    .forEach((el) => el.addEventListener('click', closeMenu));

  // ——重要修复点2：用 pointerdown 判断“点外面关闭”，避免 click 冒泡时误关、误拦截——
  function handleOutsidePointerDown(e) {
    if (!mobileMenu.classList.contains('open')) return;
    if (topNav.contains(e.target)) return; // 在导航内部点击不关闭（包含菜单本身）
    closeMenu();
  }
  document.addEventListener('pointerdown', handleOutsidePointerDown);

  // ESC 关闭
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenu(); });

  // 宽度变大时自动收起
  window.addEventListener('resize', () => { if (window.innerWidth >= 768) closeMenu(); });

  // 二级折叠
  document.querySelectorAll('.mobile-acc-btn').forEach((accBtn) => {
    accBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation(); // 不让它触发外部关闭
      const box  = accBtn.nextElementSibling;     // .mobile-submenu
      const chev = accBtn.querySelector('.chev'); // 箭头
      const show = !box.classList.contains('show');
      box.classList.toggle('show', show);
      if (chev) chev.style.transform = show ? 'rotate(180deg)' : 'rotate(0deg)';
    });
  });

  // ——重要修复点3：清理任何“残留锁滚/遮罩”——
  // （万一之前打开过语言弹窗或第三方小部件留下锁滚类名）
  const cleanupOverlay = () => {
    document.body.classList.remove('hc-scroll-lock', 'modal-open');
    const ghostLangModal = document.getElementById('lang-modal');
    if (ghostLangModal && ghostLangModal.getAttribute('aria-hidden') === 'true') {
      ghostLangModal.remove();
    }
  };
  cleanupOverlay();
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') cleanupOverlay();
  });
});

/* ====== Patch 1：Footer 折叠忽略语言按钮那一行 ====== */
ready(() => {
  const footer = document.querySelector('footer');
  if (!footer) return;

  const langBtn1 = document.getElementById('footer-language-button');
  const langBtn2 = document.getElementById('footer-language-button-mobile');

  // 在 footer 里找到“可能被绑定成折叠标题”的元素
  const headers = footer.querySelectorAll('.footer-acc-btn, [data-acc="footer"], .accordion-button');
  headers.forEach(h => {
    // 如果这个标题元素里包含语言按钮，就给它打个标记，后续折叠逻辑不要管它
    if ((langBtn1 && h.contains(langBtn1)) || (langBtn2 && h.contains(langBtn2))) {
      h.setAttribute('data-skip-accordion', '1');
    }
  });
});

/* ====== Patch 2：强力（捕获阶段）绑定语言按钮点击 ====== */
ready(() => {
  function ensureOpenLangModal(e) {
    e.preventDefault();
    e.stopPropagation();
    if (typeof openLangModal === 'function') {
      openLangModal();
    } else {
      console.warn('openLangModal 未定义：请确认语言模块是否已加载');
    }
  }

  ['lang-toggle', 'mobile-lang-toggle', 'footer-language-button', 'footer-language-button-mobile']
    .map(id => document.getElementById(id))
    .filter(Boolean)
    .forEach(btn => {
      // 先移除可能的默认 href 行为
      btn.setAttribute('href', 'javascript:void(0)');
      // 用捕获阶段绑定，优先于其他监听器执行
      btn.addEventListener('click', ensureOpenLangModal, true);
      btn.addEventListener('touchstart', ensureOpenLangModal, true);
    });
});

/* ====== Patch 3：修正 Footer 折叠绑定（若你用的是我提供的折叠脚本） ======
   让折叠脚本在绑定 click 前先检查 data-skip-accordion 标记
*/
ready(() => {
  const footer = document.querySelector('footer');
  if (!footer) return;

  const headers = footer.querySelectorAll('.footer-acc-btn, [data-acc="footer"], .accordion-button');
  headers.forEach(header => {
    // 已标记跳过的标题，不绑定折叠逻辑
    if (header.getAttribute('data-skip-accordion') === '1') return;

    // 找内容面板（与你现有折叠脚本一致即可）
    let panel = header.nextElementSibling;
    const isPanel = (el) => !!el && (el.classList?.contains('footer-acc-content') || el.classList?.contains('accordion-content'));
    if (!isPanel(panel)) {
      panel = header.parentElement?.querySelector('.footer-acc-content, .accordion-content');
    }
    if (!isPanel(panel)) return;

    const isMobile = () => window.matchMedia('(max-width: 767.98px)').matches;

    // 只在移动端执行折叠切换；桌面端不拦截点击
    header.addEventListener('click', (ev) => {
      if (!isMobile()) return;
      // 注意：不要 preventDefault/stopPropagation，避免影响语言按钮
      if (panel.style.maxHeight) {
        panel.style.maxHeight = null;
        header.classList.remove('open');
        panel.classList.remove('open');
      } else {
        // 关闭其它
        footer.querySelectorAll('.footer-acc-content, .accordion-content').forEach(p => {
          if (p !== panel) { p.style.maxHeight = null; p.classList.remove('open'); }
        });
        footer.querySelectorAll('.footer-acc-btn, [data-acc="footer"], .accordion-button').forEach(h => h.classList.remove('open'));

        panel.style.maxHeight = panel.scrollHeight + 'px';
        panel.classList.add('open');
        header.classList.add('open');
      }
    });
  });
});

(function () {
  "use strict";

  // 简单的 DOM 就绪
  function ready(fn){
    if(document.readyState!=="loading"){ fn(); }
    else document.addEventListener("DOMContentLoaded", fn);
  }

  ready(function () {
    // 1) 初始时全部收起
    document.querySelectorAll(".accordion-item .accordion-content").forEach(function (panel) {
      panel.style.maxHeight = "0px";
    });
    document.querySelectorAll(".accordion-button").forEach(function (btn) {
      btn.setAttribute("aria-expanded", "false");
    });

    // 2) 用事件委托，保证动态内容/所有页面都能生效
    document.addEventListener("click", function (e) {
      const btn = e.target.closest(".accordion-button");
      if (!btn) return;

      const item  = btn.closest(".accordion-item");
      const panel = item && item.querySelector(".accordion-content");
      if (!panel) return;

      const expanded = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", expanded ? "false" : "true");
      item.classList.toggle("open", !expanded);

      // slide 展开/收起
      if (!expanded) {
        panel.style.maxHeight = panel.scrollHeight + "px";
      } else {
        panel.style.maxHeight = "0px";
      }
    });
  });
})();

(function(){
  function buildLocaleUrl(targetLc){
    var re = /\/hc\/([a-z\-]+)(?=\/|$)/i;
    var path = location.pathname.replace(re, '/hc/' + targetLc);
    return path + location.search + location.hash;
  }
  function getCurrLc(){
    var m = location.pathname.match(/\/hc\/([a-z\-]+)(?=\/|$)/i);
    return (m && m[1]) ? m[1].toLowerCase() : 'en-us';
  }

  var curr = getCurrLc();
  document.querySelectorAll('.lang-dd [data-locale]').forEach(function(a){
    var lc = (a.getAttribute('data-locale') || '').toLowerCase();
    a.href = buildLocaleUrl(lc);
    if (lc === curr) a.setAttribute('aria-current', 'true');  // 仅语义，不做样式
  });
})();

(function(){
  var ENTER_MS = 260; // 和 style.css 里 @keyframes hcPageEnter 的时长保持一致

  function runEnter(){
    var root = document.documentElement;
    // 从“预入场”切到入场动画
    root.classList.remove('hc-entering');
    root.classList.add('hc-enter');
    // 动画结束进入 ready 状态
    setTimeout(function(){
      root.classList.remove('hc-enter');
      root.classList.add('hc-ready');
    }, ENTER_MS);
  }

  if (document.readyState !== 'loading') runEnter();
  else document.addEventListener('DOMContentLoaded', runEnter);
})();

(function(){
  // …你现有的 buildLocaleUrl / currLc / 打开收起下拉等逻辑保留…

  var EXIT_MS = 140; // 与 style.css 中 .hc-fadeout 的过渡时长一致或略大一点
  function fadeThenGo(url){
    var root = document.documentElement;
    // 告诉“下一页”要做淡入
    sessionStorage.setItem('hc_fade_next', '1');
    // 当前页先淡出
    root.classList.add('hc-fadeout');
    setTimeout(function(){ location.assign(url); }, EXIT_MS);
  }

  // 监听语言项点击（保留中键/新开窗口不拦截）
  var grp = document.querySelector('.lang-group');
  if (!grp) return;
  grp.addEventListener('click', function(e){
    var a = e.target.closest('.lang-dd a[data-locale]');
    if (!a) return;
    if (e.button !== 0 || e.metaKey || e.ctrlKey || a.target === '_blank') return;
    e.preventDefault();
    grp.classList.remove('open');
    fadeThenGo(a.href);
  });
})();